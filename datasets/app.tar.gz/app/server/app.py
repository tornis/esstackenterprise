from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from elasticapm.contrib.flask import ElasticAPM
from flask_cors import CORS

app = Flask(__name__)

# Configuração do banco de dados
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://userapp:123@localhost:5432/app'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True 

# Configuração do Elastic APM
app.config['ELASTIC_APM'] = {
    'SERVICE_NAME': 'flask-app',
    'SERVER_URL': 'http://www.tornis.com.br:8200',
    'DEBUG': True
}

apm = ElasticAPM(app)

db = SQLAlchemy(app)

CORS(app, resources={r"/*":{"origins":"*"}})

class Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)

@app.route('/items', methods=['POST'])
def create_item():
    data = request.get_json()
    item = Item(name=data['name'])
    db.session.add(item)
    db.session.commit()
    return jsonify({'message': 'Item created!'}), 201

@app.route('/items', methods=['GET'])
def get_items():
    items = Item.query.all()
    return jsonify([{'id': item.id, 'name': item.name} for item in items])

@app.route('/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    item = Item.query.get_or_404(item_id)
    return jsonify(item.name)

@app.route('/items/<int:item_id>', methods=['PUT'])
def update_item(item_id):
    item = Item.query.get_or_404(item_id)
    data = request.get_json()
    item.name = data['name']
    db.session.commit()
    return jsonify({'message': 'Item updated!'})

@app.route('/items/<int:item_id>', methods=['DELETE'])
def delete_item(item_id):
    item = Item.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return jsonify({'message': 'Item deleted!'})

if __name__ == '__main__':
    app.run(debug=True)

