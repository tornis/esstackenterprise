import { List, ListItem, ListItemText, IconButton, TextField, Button } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import React, { useEffect, useState } from "react";

function App() {
  const [items, setItems] = useState([]);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    fetch('http://lab.tornis.com.br:5000/items')
      .then(response => response.json())
      .then(data => setItems(data));
  }, []);

  const addItem = () => {
    fetch('http://lab.tornis.com.br:5000/items', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name: inputValue }),
    })
    .then(response => response.json())
    .then(() => {
      setInputValue('');
      return fetch('http://lab.tornis.com.br:5000/items');
    })
    .then(response => response.json())
    .then(data => setItems(data));
  };

  const deleteItem = (itemId) => {
    fetch(`http://lab.tornis.com.br:5000/items/${itemId}`, {
      method: 'DELETE',
    })
    .then(() => fetch('http://lab.tornis.com.br:5000/items'))
    .then(response => response.json())
    .then(data => setItems(data));
  };

  return (
    <div style={{ padding: '40px', maxWidth: '600px', margin: '0 auto' }}>
      <h1>Items</h1>
      <div style={{ display: 'flex', marginBottom: '20px' }}>
        <TextField
          fullWidth
          variant="outlined"
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          placeholder="Add new item"
        />
        <Button variant="contained" color="primary" onClick={addItem} style={{ marginLeft: '10px' }}>
          Add
        </Button>
      </div>
      <List>
        {items.map(item => (
          <ListItem key={item.id} style={{ marginBottom: '10px', backgroundColor: '#f5f5f5', borderRadius: '5px' }}>
            <ListItemText primary={item.name} />
            <IconButton edge="end" aria-label="delete" onClick={() => deleteItem(item.id)}>
              <DeleteIcon />
            </IconButton>
          </ListItem>
        ))}
      </List>
    </div>
  );
}

export default App;
