"""
Regra para reduzir todos os primeiros e médios nomes a uma única inicial escolhida aleatoriamente.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

def aplicar_regra(texto):
    """
    Reduz todos os primeiros e médios nomes a uma única inicial escolhida aleatoriamente,
    mantendo o último nome intacto.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com os primeiros e médios nomes reduzidos a uma única inicial.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    if len(palavras) <= 1:
        return texto  # Não há o que modificar se só há uma palavra
    
    # Considerar a última palavra como sobrenome
    sobrenome = palavras[-1]
    
    # Filtrar palavras que não são preposições
    nomes = [p for p in palavras[:-1] if p.lower() not in ["de", "da", "do", "das", "dos"]]
    
    # Se não houver nomes válidos, retornar o texto original
    if not nomes:
        return texto
    
    # Escolher aleatoriamente um nome para transformar em inicial
    nome_escolhido = random.choice(nomes)
    inicial = f"{nome_escolhido[0]}."
    
    # Substituir o nome escolhido pela inicial
    resultado = []
    for palavra in palavras[:-1]:
        if palavra == nome_escolhido:
            resultado.append(inicial)
        else:
            resultado.append(palavra)
    
    # Adicionar o sobrenome
    resultado.append(sobrenome)
    
    nome_modificado = " ".join(resultado)
    
    logger.info(f"Regra 'firstname_initials_single' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes com múltiplas palavras,
    ideais para a regra 'firstname_initials_single'.
    """
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.split(' ').length > 2",
                                "lang": "painless"
                            }
                        }
                    }
                ],
                "must_not": [
                    {
                        "regexp": {
                            "nome": "[A-Z]\\."
                        }
                    }
                ]
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    # Extrair a inicial e o sobrenome
    partes = nome_modificado.split()
    if not partes:
        return None
    
    # Identificar a inicial (formato "X.")
    inicial = None
    for parte in partes:
        if len(parte) == 2 and parte[1] == ".":
            inicial = parte[0]
            break
    
    sobrenome = partes[-1]
    
    query = {
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "nome": {
                                "query": sobrenome,
                                "boost": 2.0
                            }
                        }
                    }
                ],
                "should": inicial and [
                    {
                        "regexp": {
                            "nome": f".*{inicial}.*{sobrenome}"
                        }
                    }
                ] or []
            }
        }
    }
    
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
