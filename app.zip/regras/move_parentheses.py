"""
Módulo para a regra move_parentheses (mover parênteses para posições aleatórias dentro do nome)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Move um par de parênteses para posições aleatórias dentro do texto,
    mantendo a ordem de abertura e fechamento.
    Se não houver parênteses, adiciona em posições aleatórias.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com os parênteses movidos ou adicionados
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Verificar se o texto já contém parênteses
    parentese_aberto_encontrado = "(" in texto
    parentese_fechado_encontrado = ")" in texto
    
    # Remover os parênteses existentes, se houver
    if parentese_aberto_encontrado:
        texto = texto.replace("(", "", 1)  # Remove apenas a primeira ocorrência
    if parentese_fechado_encontrado:
        texto = texto.replace(")", "", 1)  # Remove apenas a primeira ocorrência
    
    # Escolher posições aleatórias para inserir os parênteses
    # Garantir que o parêntese de abertura venha antes do fechamento
    posicao_abertura = random.randint(0, len(texto))
    posicao_fechamento = random.randint(posicao_abertura, len(texto))
    
    # Inserir os parênteses nas posições escolhidas
    texto_modificado = texto[:posicao_abertura] + "(" + texto[posicao_abertura:posicao_fechamento] + ")" + texto[posicao_fechamento:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_move_parentheses(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham parênteses para a regra move_parentheses.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para move_parentheses, queremos nomes que contenham parênteses
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "bool": {
                            "should": [
                                {
                                    "wildcard": {
                                        "nome": "*(*"  # Buscar nomes que contenham parêntese de abertura
                                    }
                                },
                                {
                                    "wildcard": {
                                        "nome": "*)*"  # Buscar nomes que contenham parêntese de fechamento
                                    }
                                }
                            ],
                            "minimum_should_match": 1
                        }
                    }
                ]
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'move_parentheses': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham parênteses para a regra move_parentheses.
    Se não encontrar nomes suficientes com parênteses, complementa com nomes aleatórios.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes com parênteses do índice {MAIN_INDEX_NAME} para a regra 'move_parentheses'")
        
        # Construir a query para move_parentheses
        query = construir_query_move_parentheses(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome contém parênteses
                tem_parentese_aberto = "(" in nome
                tem_parentese_fechado = ")" in nome
                
                if tem_parentese_aberto or tem_parentese_fechado:
                    # Adicionar metadados adicionais
                    if tem_parentese_aberto:
                        hit['_source']['posicao_parentese_aberto'] = nome.find("(")
                    if tem_parentese_fechado:
                        hit['_source']['posicao_parentese_fechado'] = nome.find(")")
                    
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para move_parentheses: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes com parênteses para a regra 'move_parentheses'")
        
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'move_parentheses'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'move_parentheses'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
