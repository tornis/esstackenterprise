# Pacote de regras fonéticas/grafêmicas
# Este arquivo torna o diretório regras/ um pacote Python
