"""
Módulo para a regra transpose_cmn_dbl (transpõe sequências comuns de dois caracteres)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

# Sequências comuns de dois caracteres em português
SEQUENCIAS_COMUNS = [
    'ar', 'er', 'ir', 'or', 'ur',  # Terminações verbais
    'an', 'en', 'in', 'on', 'un',  # Nasais
    'os', 'as', 'es', 'is', 'us',  # Plurais
    'ra', 're', 'ri', 'ro', 'ru',  # Combinações com R
    'la', 'le', 'li', 'lo', 'lu',  # Combinações com L
    'ca', 'co', 'cu', 'ce', 'ci',  # Combinações com C
    'pa', 'pe', 'pi', 'po', 'pu',  # Combinações com P
    'ma', 'me', 'mi', 'mo', 'mu',  # Combinações com M
    'ta', 'te', 'ti', 'to', 'tu',  # Combinações com T
    'nt', 'nd', 'mb', 'mp', 'ng',  # Combinações consonantais
    'ch', 'lh', 'nh', 'rr', 'ss',  # Dígrafos
    'qu', 'gu'                      # Outros dígrafos
]

def aplicar_regra(texto):
    """
    Transpõe sequências comuns de dois caracteres no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com sequências comuns de dois caracteres transpostas
    """
    return transpor_sequencia_comum(texto)

def transpor_sequencia_comum(texto):
    """
    Transpõe sequências comuns de dois caracteres no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com sequências comuns de dois caracteres transpostas
    """
    if len(texto) < 2:
        return texto
    
    # Encontrar todas as ocorrências de sequências comuns no texto
    ocorrencias = []
    for i in range(len(texto) - 1):
        sequencia = texto[i:i+2].lower()
        if sequencia in SEQUENCIAS_COMUNS:
            ocorrencias.append(i)
    
    # Se não encontrou nenhuma sequência comum, retorna o texto original
    if not ocorrencias:
        return texto
    
    # Escolher aleatoriamente uma das ocorrências para transpor
    idx = random.choice(ocorrencias)
    
    # Transpor os caracteres da sequência escolhida
    return texto[:idx] + texto[idx+1] + texto[idx] + texto[idx+2:]


# Funções para busca de amostras

def construir_query_transpose_cmn_dbl(texto_base="", max_samples=50):
    """
    Constrói uma query específica para a regra transpose_cmn_dbl.
    Esta query busca nomes que contenham sequências comuns de dois caracteres.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para transpose_cmn_dbl, queremos nomes que contenham sequências comuns de dois caracteres
    should_clauses = []
    for seq in SEQUENCIAS_COMUNS:
        should_clauses.append({
            "wildcard": {
                "nome": f"*{seq}*"
            }
        })
    
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": should_clauses,
                "minimum_should_match": 1
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'transpose_cmn_dbl': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def encontrar_sequencias_comuns(texto):
    """
    Encontra todas as sequências comuns de dois caracteres no texto.
    
    Args:
        texto (str): O texto a ser analisado
        
    Returns:
        list: Lista de tuplas (índice, sequência) das sequências comuns encontradas
    """
    sequencias = []
    for i in range(len(texto) - 1):
        sequencia = texto[i:i+2].lower()
        if sequencia in SEQUENCIAS_COMUNS:
            sequencias.append((i, sequencia))
    return sequencias


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes adequados para a regra transpose_cmn_dbl.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'transpose_cmn_dbl'")
        
        # Construir a query para transpose_cmn_dbl
        query = construir_query_transpose_cmn_dbl(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Encontrar sequências comuns no nome
                sequencias = encontrar_sequencias_comuns(nome)
                
                # Se encontrou sequências comuns, adicionar à lista de nomes encontrados
                if sequencias:
                    # Escolher uma sequência aleatória para exibir na interface
                    idx, seq = random.choice(sequencias)
                    
                    # Adicionar metadados adicionais
                    hit['_source']['sequencia_comum'] = seq
                    hit['_source']['indice_sequencia'] = idx
                    hit['_source']['transposicao'] = nome[:idx] + nome[idx+1] + nome[idx] + nome[idx+2:]
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para transpose_cmn_dbl: {nome}, sequência: {seq}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes adequados para a regra 'transpose_cmn_dbl'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'transpose_cmn_dbl'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'transpose_cmn_dbl'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
