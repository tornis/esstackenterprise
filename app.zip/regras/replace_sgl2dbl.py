"""
Módulo para a regra replace_sgl2dbl (duplicação de letras)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Duplica uma letra aleatória no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com uma letra duplicada
    """
    return duplicar_letra_aleatoria(texto)

def duplicar_letra_aleatoria(texto):
    """
    Duplica uma letra aleatória no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com uma letra duplicada
    """
    if len(texto) < 2:
        return texto
    
    # Escolher uma posição aleatória (exceto a última para evitar duplicar espaços)
    posicao = random.randint(0, len(texto) - 2)
    
    # Duplicar a letra na posição escolhida
    return texto[:posicao] + texto[posicao] + texto[posicao:]


# Funções para busca de amostras

def construir_query_replace_sgl2dbl(texto_base="", max_samples=50):
    """
    Constrói uma query específica para a regra replace_sgl2dbl.
    Esta query busca nomes que não contenham letras duplicadas e que tenham pelo menos 4 caracteres.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para replace_sgl2dbl, queremos apenas nomes que não contenham letras duplicadas
    # e que tenham pelo menos 4 caracteres para que a duplicação seja mais significativa
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "match_all": {}
                    }
                ],
                "must_not": [
                    # Excluir nomes que já contenham letras duplicadas
                    {
                        "regexp": {
                            "nome": ".*([a-zA-Z])\\1+.*"  # Expressão regular para encontrar letras duplicadas
                        }
                    }
                ],
                "filter": [
                    # Filtrar por tamanho mínimo
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.length() >= 4"
                            }
                        }
                    }
                ]
            }
        },
        "sort": [
            # Ordenação aleatória para diversidade nos resultados
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'replace_sgl2dbl': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes adequados para a regra replace_sgl2dbl.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'replace_sgl2dbl'")
        
        # Construir a query específica para replace_sgl2dbl
        query = construir_query_replace_sgl2dbl(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome não contém letras duplicadas (já filtrado na query, mas verificar novamente)
                if not re.search(r'([a-zA-Z])\1+', nome):
                    # Adicionar metadados adicionais
                    hit['_source']['tamanho_original'] = len(nome)
                    # Identificar letras que podem ser duplicadas (vogais e consoantes comuns)
                    letras_duplicaveis = re.findall(r'[aeioursln]', nome.lower())
                    hit['_source']['letras_duplicaveis'] = letras_duplicaveis
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado para duplicação encontrado: {nome} (letras duplicaveis: {letras_duplicaveis})")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'replace_sgl2dbl'")
        
        # Ordenar os resultados para priorizar nomes com mais letras duplicaveis
        if nomes_encontrados:
            # Ordenar por quantidade de letras duplicaveis (mais letras primeiro)
            nomes_encontrados.sort(key=lambda x: len(re.findall(r'[aeioursln]', x.get('nome', '').lower())), reverse=True)
            logger.info(f"Nomes ordenados por quantidade de letras duplicaveis")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'replace_sgl2dbl'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'replace_sgl2dbl'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
