"""
Módulo para a regra replace_1st_char (substituir o primeiro caractere do nome por um caractere alfabético aleatório)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

# Lista de caracteres alfabéticos para substituição
CARACTERES_ALFABETICOS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'

def aplicar_regra(texto):
    """
    Substitui o primeiro caractere do texto por um caractere alfabético aleatório.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com o primeiro caractere substituído
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Escolher um caractere alfabético aleatório diferente do original
    primeiro_char = texto[0]
    caracteres_disponiveis = CARACTERES_ALFABETICOS.replace(primeiro_char, '')
    
    if not caracteres_disponiveis:
        # Caso improvável, mas se não houver caracteres disponíveis, retornar o texto original
        return texto
    
    novo_char = random.choice(caracteres_disponiveis)
    
    # Substituir o primeiro caractere pelo novo caractere
    texto_modificado = novo_char + texto[1:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_replace_1st_char(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que comecem com caracteres alfabéticos para a regra replace_1st_char.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para replace_1st_char, queremos nomes que comecem com caracteres alfabéticos
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "regexp": {
                            "nome": "[a-zA-Z].*"  # Nomes que começam com caracteres alfabéticos
                        }
                    }
                ]
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'replace_1st_char': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que comecem com caracteres alfabéticos para a regra replace_1st_char.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes que comecem com caracteres alfabéticos do índice {MAIN_INDEX_NAME} para a regra 'replace_1st_char'")
        
        # Construir a query para replace_1st_char
        query = construir_query_replace_1st_char(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome começa com caractere alfabético
                if nome and re.match(r'^[a-zA-Z]', nome):
                    # Adicionar metadados adicionais
                    hit['_source']['primeiro_caractere'] = nome[0]
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para replace_1st_char: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes que começam com caracteres alfabéticos para a regra 'replace_1st_char'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'replace_1st_char'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'replace_1st_char'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
