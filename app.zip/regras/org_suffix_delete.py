"""
Módulo para a regra org_suffix_delete (remove palavras comumente usadas como sufixos em nomes de organizações)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

# Lista de sufixos comuns em nomes de organizações
SUFIXOS_ORGANIZACOES = [
    'ltda', 'ltda.', 'ltd', 'ltd.', 'limitada',
    'corp', 'corp.', 'corporation', 'inc', 'inc.',
    'incorporated', 's.a.', 'sa', 's/a', 'companhia',
    'cia', 'cia.', 'co', 'co.', 'company',
    'group', 'grupo', 'holdings', 'holding',
    'enterprises', 'industries', 'international',
    'gmbh', 'ag', 'plc', 'llc', 'llp',
    'associados', 'associação', 'foundation',
    'fundação', 'instituto', 'institute',
    'serviços', 'services', 'solutions',
    'tecnologia', 'technology', 'systems',
    'sistemas', 'consultoria', 'consulting',
    'partners', 'parceiros', 'brasil', 'brazil',
    'global', 'nacional', 'federal', 'estadual',
    'municipal', 'regional', 'local', 'central',
    'comercial', 'industrial', 'importação',
    'exportação', 'distribuidora', 'distribuição',
    'representações', 'comércio', 'varejo',
    'atacado', 'engenharia', 'construtora',
    'construções', 'incorporadora', 'imobiliária',
    'empreendimentos', 'participações', 'investimentos',
    'banco', 'financeira', 'seguros', 'seguradora',
    'corretora', 'administradora', 'gestão',
    'educação', 'ensino', 'escola', 'colégio',
    'universidade', 'faculdade', 'hospital',
    'clínica', 'saúde', 'farmácia', 'laboratório',
    'alimentos', 'bebidas', 'restaurante',
    'transportes', 'logística', 'turismo',
    'viagens', 'hotéis', 'hotelaria', 'comunicação',
    'mídia', 'publicidade', 'propaganda', 'marketing',
    'informática', 'software', 'hardware',
    'telecomunicações', 'energia', 'petróleo',
    'gás', 'mineração', 'siderurgia', 'metalurgia',
    'química', 'farmacêutica', 'cosméticos',
    'têxtil', 'confecções', 'calçados', 'móveis',
    'madeira', 'papel', 'celulose', 'plásticos',
    'borracha', 'vidro', 'cerâmica', 'materiais',
    'equipamentos', 'máquinas', 'ferramentas',
    'automóveis', 'veículos', 'autopeças',
    'eletrônicos', 'eletrodomésticos', 'segurança',
    'limpeza', 'manutenção', 'jardinagem',
    'paisagismo', 'decoração', 'design',
    'arquitetura', 'contabilidade', 'auditoria',
    'assessoria', 'advocacia', 'jurídica',
    'agropecuária', 'agrícola', 'pecuária',
    'florestal', 'ambiental', 'reciclagem',
    'tratamento', 'resíduos', 'saneamento',
    'água', 'esgoto', 'elétrica', 'hidráulica',
    'mecânica', 'eletrônica', 'automação',
    'robótica', 'digital', 'virtual', 'online',
    'web', 'internet', 'network', 'rede',
    'cloud', 'nuvem', 'data', 'dados', 'info',
    'informação', 'conhecimento', 'pesquisa',
    'desenvolvimento', 'inovação', 'criação',
    'produção', 'fabricação', 'manufatura',
    'montagem', 'instalação', 'manutenção',
    'assistência', 'suporte', 'atendimento',
    'vendas', 'locação', 'aluguel', 'leasing',
    'franchising', 'franquia', 'licenciamento',
    'certificação', 'qualidade', 'gestão',
    'administração', 'planejamento', 'estratégia',
    'consultoria', 'assessoria', 'treinamento',
    'capacitação', 'recursos', 'humanos',
    'pessoal', 'profissional', 'técnico',
    'especializado', 'oficial', 'autorizado',
    'registrado', 'credenciado', 'homologado'
]

def aplicar_regra(texto):
    """
    Remove palavras comumente usadas como sufixos em nomes de organizações.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto sem os sufixos de organizações
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto or len(texto) == 0:
        return texto
    
    # Dividir o texto em palavras
    palavras = texto.split()
    
    # Se houver apenas uma palavra, retornar o texto original
    if len(palavras) <= 1:
        return texto
    
    # Verificar se a última palavra é um sufixo comum de organização
    ultima_palavra = palavras[-1].lower().strip('.,;:()[]{}')
    
    if ultima_palavra in SUFIXOS_ORGANIZACOES:
        # Remover o sufixo e retornar o texto sem ele
        return " ".join(palavras[:-1])
    
    # Se não encontrou sufixo, retornar o texto original
    return texto


# Funções para busca de amostras

def construir_query_org_suffix_delete(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham sufixos comuns de organizações.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Criar cláusulas should para cada sufixo de organização
    should_clauses = []
    for sufixo in SUFIXOS_ORGANIZACOES:
        should_clauses.append({
            "wildcard": {
                "nome": f"{sufixo}"
            }
        })
        should_clauses.append({
            "wildcard": {
                "nome": f"{sufixo}."
            }
        })
    
    # Para org_suffix_delete, queremos nomes que terminem com sufixos comuns de organizações
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": should_clauses,
                "minimum_should_match": 1
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'org_suffix_delete': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham sufixos comuns de organizações.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'org_suffix_delete'")
        
        # Construir a query para org_suffix_delete
        query = construir_query_org_suffix_delete(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Dividir o texto em palavras
                palavras = nome.split()
                
                # Verificar se a última palavra é um sufixo comum de organização
                if len(palavras) > 1:
                    ultima_palavra = palavras[-1].lower().strip('.,;:()[]{}')
                    
                    if ultima_palavra in SUFIXOS_ORGANIZACOES or ultima_palavra + '.' in SUFIXOS_ORGANIZACOES:
                        # Adicionar metadados adicionais
                        hit['_source']['sufixo_removido'] = palavras[-1]
                        hit['_source']['nome_sem_sufixo'] = " ".join(palavras[:-1])
                        nomes_encontrados.append(hit['_source'])
                        logger.info(f"Nome adequado encontrado para org_suffix_delete: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes adequados para a regra 'org_suffix_delete'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'org_suffix_delete'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'org_suffix_delete'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
