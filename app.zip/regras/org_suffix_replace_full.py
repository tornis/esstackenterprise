"""
Regra para substituir palavras completas comumente usadas como sufixos em nomes de organizações.
"""
import re
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Lista de palavras completas comuns para sufixos de organizações
PALAVRAS_SUFIXOS = [
    "Limitada", "Limited", "Sociedade Anônima", "Sociedade Anonima", "Incorporated", 
    "Corporation", "Companhia", "Company", "Empresa Individual de Responsabilidade Limitada",
    "Microempresa", "Empresa de Pequeno Porte", "Grupo", "Group", "Holdings", "Holding",
    "Empreendimentos", "Enterprises", "International", "Internacional", "Tecnologia",
    "Technology", "Serviços", "Services", "Indústria", "Industria", "Comércio", "Comercio",
    "Administração", "Administracao", "Distribuidora", "Transportes", "Consultoria",
    "Associação", "Associacao", "Participações", "Participacoes"
]

def contem_palavra_sufixo(texto):
    """
    Verifica se o texto contém alguma palavra completa conhecida como sufixo.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        tuple: (bool, palavra, posição) - Indica se contém palavra, qual e sua posição.
    """
    for palavra in PALAVRAS_SUFIXOS:
        # Verificar se a palavra está no final do texto
        if texto.endswith(f" {palavra}"):
            return True, palavra, len(texto) - len(palavra) - 1
        
        # Verificar se a palavra está em qualquer parte do texto
        posicao = texto.find(f" {palavra} ")
        if posicao != -1:
            return True, palavra, posicao + 1
    
    return False, "", -1

def aplicar_regra(texto):
    """
    Substitui palavras completas comumente usadas como sufixos em nomes de organizações.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com palavras completas de sufixos substituídas.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Verificar se o texto contém alguma palavra completa conhecida como sufixo
    contem, palavra, posicao = contem_palavra_sufixo(texto)
    
    if not contem:
        return texto  # Não há palavras para substituir
    
    # Escolher uma palavra aleatória diferente da atual
    outras_palavras = [p for p in PALAVRAS_SUFIXOS if p != palavra]
    if outras_palavras:
        nova_palavra = random.choice(outras_palavras)
        
        # Substituir a palavra
        if posicao >= 0:
            nome_modificado = texto[:posicao] + nova_palavra + texto[posicao + len(palavra):]
            logger.info(f"Regra 'org_suffix_replace_full' aplicada: '{texto}' -> '{nome_modificado}'")
            return nome_modificado
    
    return texto

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes de organizações que contenham palavras completas conhecidas como sufixos,
    ideais para a regra 'org_suffix_replace_full'.
    """
    # Criar condições para cada palavra
    should_conditions = []
    for palavra in PALAVRAS_SUFIXOS:
        should_conditions.append({
            "match_phrase": {
                "nome": palavra
            }
        })
    
    return {
        "query": {
            "bool": {
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
