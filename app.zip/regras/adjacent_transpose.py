"""
Módulo para as regras de transposição de caracteres adjacentes
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Transpõe dois caracteres adjacentes aleatórios no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com dois caracteres adjacentes transpostos
    """
    return transpor_caracteres_adjacentes(texto)

def transpor_caracteres_adjacentes(texto):
    """
    Transpõe dois caracteres adjacentes aleatórios no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com dois caracteres adjacentes transpostos
    """
    if len(texto) < 2:
        return texto
    
    idx = random.randint(0, len(texto) - 2)
    return texto[:idx] + texto[idx+1] + texto[idx] + texto[idx+2:]

def transpor_caracteres_adjacentes_inicio(texto):
    """
    Transpõe os dois primeiros caracteres do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com os dois primeiros caracteres transpostos
    """
    if len(texto) < 2:
        return texto
    
    return texto[1] + texto[0] + texto[2:]

def transpor_caracteres_adjacentes_fim(texto):
    """
    Transpõe os dois últimos caracteres do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com os dois últimos caracteres transpostos
    """
    if len(texto) < 2:
        return texto
    
    return texto[:-2] + texto[-1] + texto[-2]


# Funções para busca de amostras

def construir_query_adjacent_transpose(texto_base, max_samples=50, fuzziness="AUTO", operator="or"):
    """
    Constrói uma query específica para a regra adjacent_transpose.
    Esta query busca nomes que tenham pelo menos 3 caracteres para permitir transposições significativas.
    
    Args:
        texto_base (str): O texto base para a busca
        max_samples (int): Número máximo de amostras a retornar
        fuzziness (str): Nível de fuzziness para a busca
        operator (str): Operador para a busca ("and" ou "or")
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para adjacent_transpose, queremos nomes que tenham pelo menos 3 caracteres
    # e preferencialmente com pares de letras comuns que são frequentemente transpostos
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "nome": {
                                "query": texto_base,
                                "fuzziness": fuzziness,
                                "operator": operator
                            }
                        }
                    }
                ],
                "should": [
                    # Buscar nomes com pares de letras comumente transpostos
                    {"wildcard": {"nome": "*er*"}},
                    {"wildcard": {"nome": "*re*"}},
                    {"wildcard": {"nome": "*ar*"}},
                    {"wildcard": {"nome": "*ra*"}},
                    {"wildcard": {"nome": "*el*"}},
                    {"wildcard": {"nome": "*le*"}},
                    {"wildcard": {"nome": "*an*"}},
                    {"wildcard": {"nome": "*na*"}},
                    {"wildcard": {"nome": "*ia*"}},
                    {"wildcard": {"nome": "*ai*"}},
                    {"wildcard": {"nome": "*io*"}},
                    {"wildcard": {"nome": "*oi*"}}
                ],
                "filter": [
                    # Filtrar por tamanho mínimo
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.length() >= 3"
                            }
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        },
        "sort": [
            # Ordenar por tamanho do nome (decrescente)
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "doc['nome.keyword'].value.length()"
                    },
                    "order": "desc"
                }
            },
            "_score"
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'adjacent_transpose': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def identificar_pares_transponiveis(texto):
    """
    Identifica pares de caracteres que são bons candidatos para transposição.
    
    Args:
        texto (str): O texto a ser analisado
        
    Returns:
        list: Lista de índices onde os pares de caracteres podem ser transpostos
    """
    pares_transponiveis = []
    
    # Pares comuns que são frequentemente transpostos
    pares_comuns = ['er', 're', 'ar', 'ra', 'el', 'le', 'an', 'na', 'ia', 'ai', 'io', 'oi']
    
    # Verificar cada posição no texto
    for i in range(len(texto) - 1):
        par = texto[i:i+2].lower()
        # Se o par é um dos pares comuns, adicionar o índice à lista
        if par in pares_comuns:
            pares_transponiveis.append(i)
    
    return pares_transponiveis


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes adequados para a regra adjacent_transpose.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'adjacent_transpose'")
        
        # Construir a query específica para adjacent_transpose
        query = construir_query_adjacent_transpose(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome tem tamanho suficiente
                if len(nome) >= 3:
                    # Identificar pares de caracteres que podem ser transpostos
                    pares_transponiveis = identificar_pares_transponiveis(nome)
                    
                    # Adicionar metadados adicionais
                    hit['_source']['tamanho_original'] = len(nome)
                    hit['_source']['pares_transponiveis'] = pares_transponiveis
                    hit['_source']['num_pares_transponiveis'] = len(pares_transponiveis)
                    
                    # Adicionar à lista de nomes encontrados
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado para transposição encontrado: {nome} (pares: {len(pares_transponiveis)})")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'adjacent_transpose'")
        
        # Ordenar os resultados para priorizar nomes com mais pares transponiveis
        if nomes_encontrados:
            # Ordenar por quantidade de pares transponiveis (mais pares primeiro)
            nomes_encontrados.sort(key=lambda x: x.get('num_pares_transponiveis', 0), reverse=True)
            logger.info(f"Nomes ordenados por quantidade de pares transponiveis")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'adjacent_transpose'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'adjacent_transpose'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
