"""
Regra para alterar a ordem das palavras no sobrenome de um indivíduo.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

def aplicar_regra(texto):
    """
    Altera a ordem das palavras no sobrenome de um indivíduo.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com a ordem das palavras no sobrenome alterada.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    if len(palavras) <= 2:
        return texto  # Não há o que modificar se não houver pelo menos um nome e um sobrenome composto
    
    # Identificar possíveis sobrenomes compostos (últimas duas ou mais palavras)
    # Vamos considerar que o sobrenome pode ser composto por até 3 palavras
    sobrenome_composto = False
    tamanho_sobrenome = 1
    
    # Verificar se temos um sobrenome composto (2 ou 3 palavras)
    for i in range(2, min(4, len(palavras) + 1)):
        # Verificar se as últimas i palavras não são preposições comuns
        if all(palavra.lower() not in ["de", "da", "do", "das", "dos"] for palavra in palavras[-i:]):
            sobrenome_composto = True
            tamanho_sobrenome = i
            break
    
    if not sobrenome_composto:
        return texto  # Não há sobrenome composto para modificar
    
    # Separar o nome em primeiros nomes e sobrenome composto
    primeiros_nomes = palavras[:-tamanho_sobrenome]
    sobrenome = palavras[-tamanho_sobrenome:]
    
    # Embaralhar a ordem das palavras no sobrenome
    random.shuffle(sobrenome)
    
    # Reconstruir o nome
    nome_modificado = " ".join(primeiros_nomes + sobrenome)
    
    logger.info(f"Regra 'switch_last_names' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes com sobrenomes compostos,
    ideais para a regra 'switch_last_names'.
    """
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.split(' ').length > 3",
                                "lang": "painless"
                            }
                        }
                    }
                ],
                "must_not": [
                    {
                        "terms": {
                            "nome": ["ltda", "s.a.", "s/a", "s.a", "inc", "corp", "cia", "co"]
                        }
                    }
                ]
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    palavras = nome_modificado.split()
    if not palavras:
        return None
    
    # Construir uma query que busca por todas as palavras do nome
    query = {
        "query": {
            "bool": {
                "must": []
            }
        }
    }
    
    # Adicionar condições para cada palavra do nome
    for palavra in palavras:
        if palavra.lower() not in ["de", "da", "do", "das", "dos"]:  # Ignorar preposições
            query["query"]["bool"]["must"].append({
                "match": {
                    "nome": palavra
                }
            })
    
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
