"""
Módulo para a regra remove_special_char (remoção de caracteres especiais)
"""
import re
import logging
import json
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Remove caracteres especiais de um texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto sem caracteres especiais
    """
    return remover_caracteres_especiais(texto)

def remover_caracteres_especiais(texto):
    """
    Remove caracteres especiais de um texto, mantendo apenas letras, números e espaços.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto sem caracteres especiais
    """
    # Definir quais caracteres são considerados especiais
    # Mantemos letras, números e espaços, removendo todos os outros caracteres
    return re.sub(r'[^\w\s]', '', texto)

def contem_caracteres_especiais(texto):
    """
    Verifica se um texto contém caracteres especiais.
    
    Args:
        texto (str): O texto a ser verificado
        
    Returns:
        bool: True se o texto contém caracteres especiais, False caso contrário
    """
    # Verificar se há qualquer caractere que não seja letra, número ou espaço
    return bool(re.search(r'[^\w\s]', texto))

def extrair_caracteres_especiais(texto):
    """
    Extrai os caracteres especiais de um texto.
    
    Args:
        texto (str): O texto do qual extrair os caracteres especiais
        
    Returns:
        str: Uma string contendo os caracteres especiais do texto
    """
    # Extrair apenas os caracteres especiais
    especiais = re.findall(r'[^\w\s]', texto)
    return ''.join(especiais)


# Funções para busca de amostras

def construir_query_remove_special_char(texto_base, max_samples=50, fuzziness="AUTO", operator="or"):
    """
    Constrói uma query específica para a regra remove_special_char.
    Esta query busca nomes que contenham caracteres especiais.
    
    Args:
        texto_base (str): O texto base para a busca
        max_samples (int): Número máximo de amostras a retornar
        fuzziness (str): Nível de fuzziness para a busca
        operator (str): Operador para a busca ("and" ou "or")
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para remove_special_char, queremos nomes que contenham caracteres especiais
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": [
                    # Buscar nomes que contenham qualquer caractere especial
                    {
                        "regexp": {
                            "nome": ".*[^\\w\\s].*"  # Expressão regular para encontrar qualquer caractere que não seja letra, número ou espaço
                        }
                    },
                    # Adicionar também buscas específicas para caracteres especiais comuns
                    {"wildcard": {"nome": "*#*"}},
                    {"wildcard": {"nome": "*$*"}},
                    {"wildcard": {"nome": "*%*"}},
                    {"wildcard": {"nome": "*¨*"}},
                    {"wildcard": {"nome": "**"}},
                    {"wildcard": {"nome": "*+*"}},
                    {"wildcard": {"nome": "*=*"}},
                    {"wildcard": {"nome": "*{*"}},
                    {"wildcard": {"nome": "*}*"}},
                    {"wildcard": {"nome": "*[*"}},
                    {"wildcard": {"nome": "*]*"}},
                    {"wildcard": {"nome": "*<*"}},
                    {"wildcard": {"nome": "*>*"}},
                    {"wildcard": {"nome": "*,*"}},
                    {"wildcard": {"nome": "*:*"}},
                    {"wildcard": {"nome": "*;*"}},
                    {"wildcard": {"nome": "*\"*"}},
                    {"wildcard": {"nome": "*`*"}},
                    {"wildcard": {"nome": "*~*"}}
                ],
                "minimum_should_match": 1
            }
        }
    }
    
    logger.info(f"Query DSL construída para regra 'remove_special_char': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham caracteres especiais para a regra remove_special_char.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'remove_special_char'")
        
        # Construir a query específica para remove_special_char
        query = construir_query_remove_special_char(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome realmente contém caracteres especiais
                if contem_caracteres_especiais(nome):
                    # Adicionar informações sobre os caracteres especiais encontrados
                    caracteres_especiais = extrair_caracteres_especiais(nome)
                    hit['_source']['caracteres_especiais'] = caracteres_especiais
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome com caracteres especiais encontrado: {nome} (caracteres: {caracteres_especiais})")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'remove_special_char'")
        
        # Ordenar os resultados para priorizar nomes com mais caracteres especiais
        if nomes_encontrados:
            # Para a regra remove_special_char, priorizar nomes com mais caracteres especiais
            nomes_encontrados.sort(key=lambda x: len(extrair_caracteres_especiais(x.get('nome', ''))), reverse=True)
            logger.info(f"Nomes ordenados por quantidade de caracteres especiais")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'remove_special_char'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome com caracteres especiais foi encontrado para a regra 'remove_special_char'. "
                            f"Verifique se existem nomes com caracteres especiais no índice.")
            else:
                logger.info(f"Encontrados {len(nomes_encontrados)} nomes com caracteres especiais para a regra 'remove_special_char'.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
