"""
Regra para alterar a ordem das palavras em um nome de organização.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Lista de sufixos comuns de organizações para identificação
SUFIXOS_ORG = [
    "Ltda", "Ltda.", "Ltd", "Ltd.", "S.A.", "S/A", "Inc", "Inc.", "Corp", "Corp.",
    "Cia", "Cia.", "Co", "Co.", "Limitada", "Limited", "Sociedade Anônima", 
    "Incorporated", "Corporation", "Companhia", "Company", "Eireli", "ME", "EPP",
    "Grupo", "Group", "Holdings", "Holding", "Empreendimentos", "Emp.", "Enterprises",
    "Ent.", "International", "Int.", "Internacional", "Tecnologia", "Tech", 
    "Serviços", "Serv.", "Services", "Indústria", "Industria", "Comércio", "Comercio"
]

def eh_organizacao(texto):
    """
    Verifica se o texto parece ser um nome de organização.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        bool: True se parece ser uma organização, False caso contrário.
    """
    # Verificar se o texto termina com um sufixo comum de organização
    for sufixo in SUFIXOS_ORG:
        if texto.endswith(f" {sufixo}"):
            return True
    
    # Verificar se o texto contém um sufixo comum de organização
    for sufixo in SUFIXOS_ORG:
        if f" {sufixo} " in texto:
            return True
    
    return False

def aplicar_regra(texto):
    """
    Altera a ordem das palavras em um nome de organização.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com a ordem das palavras alterada.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    if len(palavras) <= 2:
        return texto  # Não há o que modificar se houver apenas uma ou duas palavras
    
    # Verificar se parece ser um nome de organização
    if not eh_organizacao(texto):
        return texto  # Não parece ser uma organização
    
    # Identificar se há um sufixo de organização no final
    sufixo_final = None
    for sufixo in SUFIXOS_ORG:
        if texto.endswith(f" {sufixo}"):
            sufixo_final = sufixo
            break
    
    if sufixo_final:
        # Separar o nome da organização do sufixo
        nome_org = palavras[:-1]
        
        # Embaralhar a ordem das palavras no nome da organização
        random.shuffle(nome_org)
        
        # Reconstruir o nome com o sufixo no final
        nome_modificado = " ".join(nome_org + [sufixo_final])
    else:
        # Identificar se há um sufixo de organização no meio
        sufixo_meio = None
        posicao_sufixo = -1
        
        for sufixo in SUFIXOS_ORG:
            posicao = texto.find(f" {sufixo} ")
            if posicao != -1:
                sufixo_meio = sufixo
                posicao_sufixo = texto[:posicao].count(" ")  # Índice da palavra que é o sufixo
                break
        
        if sufixo_meio and posicao_sufixo != -1:
            # Separar o nome em partes: antes do sufixo, o sufixo e depois do sufixo
            antes_sufixo = palavras[:posicao_sufixo]
            depois_sufixo = palavras[posicao_sufixo+1:]
            
            # Embaralhar a ordem das palavras antes e depois do sufixo
            if antes_sufixo:
                random.shuffle(antes_sufixo)
            if depois_sufixo:
                random.shuffle(depois_sufixo)
            
            # Reconstruir o nome mantendo o sufixo na mesma posição
            nome_modificado = " ".join(antes_sufixo + [sufixo_meio] + depois_sufixo)
        else:
            # Se não identificou sufixo, embaralhar todas as palavras
            palavras_copia = palavras.copy()
            random.shuffle(palavras_copia)
            nome_modificado = " ".join(palavras_copia)
    
    logger.info(f"Regra 'switch_org_names' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes de organizações,
    ideais para a regra 'switch_org_names'.
    """
    # Criar condições para cada sufixo de organização
    should_conditions = []
    for sufixo in SUFIXOS_ORG:
        should_conditions.append({
            "match_phrase": {
                "nome": sufixo
            }
        })
    
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.split(' ').length > 3",
                                "lang": "painless"
                            }
                        }
                    }
                ],
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    palavras = nome_modificado.split()
    if not palavras:
        return None
    
    # Construir uma query que busca por todas as palavras do nome
    query = {
        "query": {
            "bool": {
                "must": []
            }
        }
    }
    
    # Adicionar condições para cada palavra do nome
    for palavra in palavras:
        query["query"]["bool"]["must"].append({
            "match": {
                "nome": palavra
            }
        })
    
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
