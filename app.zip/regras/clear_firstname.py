"""
Módulo para a regra clear_firstname (exclui o primeiro nome de uma pessoa)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Exclui o primeiro nome de uma pessoa.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto sem o primeiro nome
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto or len(texto) == 0:
        return texto
    
    # Dividir o texto em palavras
    palavras = texto.split()
    
    # Se houver apenas uma palavra, retornar texto vazio
    if len(palavras) <= 1:
        return ""
    
    # Remover o primeiro nome e juntar o restante
    return " ".join(palavras[1:])


# Funções para busca de amostras

def construir_query_amostras(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar amostras aleatórias para a regra clear_firstname.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para busca de amostras, usamos match_all para obter nomes aleatórios
    query = {
        "size": max_samples,
        "query": {
            "match_all": {}
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query de amostras construída para regra 'clear_firstname': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def construir_query_busca_final(nome_modificado, max_results=50):
    """
    Constrói uma query para buscar nomes modificados após a aplicação da regra clear_firstname.
    
    Args:
        nome_modificado (str): O nome após a aplicação da regra
        max_results (int): Número máximo de resultados a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para busca final, usamos match para encontrar nomes similares ao nome modificado
    query = {
        "size": max_results,
        "query": {
            "match": {
                "nome": {
                    "query": nome_modificado,
                    "operator": "or",
                    "fuzziness": "AUTO",
                    "minimum_should_match": "1"
                }
            }
        }
    }
    
    logger.info(f"Query de busca final construída para nome modificado '{nome_modificado}': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras aleatórias para a regra clear_firstname.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} amostras aleatórias do índice {MAIN_INDEX_NAME} para a regra 'clear_firstname'")
        
        # Construir a query para busca de amostras aleatórias
        query = construir_query_amostras(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome_original = hit['_source']['nome']
                
                # Aplicar a regra usando a função aplicar_regra
                nome_modificado = aplicar_regra(nome_original)
                
                # Criar um novo dicionário simplificado com apenas os campos necessários
                amostra = {
                    'nome': nome_original,
                    'nome_modificado': nome_modificado  # Campo principal para exibição
                }
                
                # Adicionar a amostra à lista
                nomes_encontrados.append(amostra)
                logger.info(f"Nome encontrado para clear_firstname: {nome_original} -> {nome_modificado}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'clear_firstname'")
        
        # Verificar se encontrou nomes
        if len(nomes_encontrados) == 0:
            logger.error(f"Nenhum nome foi encontrado para a regra 'clear_firstname'. "
                        f"Verifique a conexão com o OpenSearch.")
                        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info


def buscar_nome_modificado(client, nome_modificado, max_results=50):
    """
    Busca nomes similares ao nome modificado após a aplicação da regra clear_firstname.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        nome_modificado (str): O nome após a aplicação da regra
        max_results (int): Número máximo de resultados a retornar
        
    Returns:
        tuple: (lista de resultados encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando nomes similares a '{nome_modificado}' no índice {MAIN_INDEX_NAME}")
        
        # Construir a query para busca de nomes similares ao nome modificado
        query = construir_query_busca_final(nome_modificado, max_results=max_results)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome_encontrado = hit['_source']['nome']
                score = hit.get('_score', 0)
                
                # Criar um dicionário com as informações do resultado
                resultado = {
                    'nome': nome_encontrado,
                    'score': score
                }
                
                # Adicionar o resultado à lista
                nomes_encontrados.append(resultado)
                logger.info(f"Nome similar encontrado: '{nome_encontrado}' (score: {score})")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes similares a '{nome_modificado}'")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False),
            'nome_modificado': nome_modificado
        }
        
        # Retornar os resultados encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes similares: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e),
            'nome_modificado': nome_modificado
        }
        
        return [], query_info
