"""
Regra para reduzir todos os primeiros e médios nomes a iniciais no campo de primeiro nome.
"""
import re
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

def aplicar_regra(texto):
    """
    Reduz todos os primeiros e médios nomes a iniciais, mantendo o último nome intacto.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com os primeiros e médios nomes reduzidos a iniciais.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    if len(palavras) <= 1:
        return texto  # Não há o que modificar se só há uma palavra
    
    # Considerar a última palavra como sobrenome
    sobrenome = palavras[-1]
    
    # Reduzir todos os primeiros e médios nomes a iniciais
    iniciais = []
    for palavra in palavras[:-1]:
        # Ignorar palavras muito curtas ou preposições comuns
        if len(palavra) <= 1 or palavra.lower() in ["de", "da", "do", "das", "dos"]:
            iniciais.append(palavra)
        else:
            iniciais.append(f"{palavra[0]}.")
    
    # Juntar as iniciais e o sobrenome
    nome_modificado = " ".join(iniciais + [sobrenome])
    
    logger.info(f"Regra 'firstname_initials' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes com múltiplas palavras,
    ideais para a regra 'firstname_initials'.
    """
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.split(' ').length > 2",
                                "lang": "painless"
                            }
                        }
                    }
                ],
                "must_not": [
                    {
                        "regexp": {
                            "nome": "[A-Z]\\."
                        }
                    }
                ]
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    # Extrair as iniciais e o sobrenome
    partes = nome_modificado.split()
    if not partes:
        return None
    
    # Construir uma query que busca por nomes que começam com as mesmas iniciais
    iniciais_pattern = ""
    for parte in partes[:-1]:
        if parte.endswith("."):
            iniciais_pattern += parte[0]
    
    sobrenome = partes[-1]
    
    query = {
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "nome": {
                                "query": sobrenome,
                                "boost": 2.0
                            }
                        }
                    }
                ],
                "should": [
                    {
                        "regexp": {
                            "nome": f".*{iniciais_pattern}.*{sobrenome}"
                        }
                    }
                ]
            }
        }
    }
    
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
