"""
Regra para substituir uma stop word aleatória por outra.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Lista de stop words em português
STOP_WORDS = [
    "a", "ao", "aos", "aquela", "aquelas", "aquele", "aqueles", "aquilo", "as", "até",
    "com", "como", "da", "das", "de", "dela", "delas", "dele", "deles", "depois",
    "do", "dos", "e", "ela", "elas", "ele", "eles", "em", "entre", "era",
    "eram", "éramos", "essa", "essas", "esse", "esses", "esta", "estas", "este", "estes",
    "eu", "foi", "fomos", "for", "foram", "fosse", "fossem", "fui", "há", "isso",
    "isto", "já", "lhe", "lhes", "mais", "mas", "me", "mesmo", "meu", "meus",
    "minha", "minhas", "muito", "na", "não", "nas", "nem", "no", "nos", "nós",
    "nossa", "nossas", "nosso", "nossos", "num", "numa", "o", "os", "ou", "para",
    "pela", "pelas", "pelo", "pelos", "por", "qual", "quando", "que", "quem", "se",
    "sem", "seu", "seus", "só", "somos", "sou", "sua", "suas", "também", "te",
    "tem", "tém", "temos", "tenho", "teu", "teus", "tu", "tua", "tuas", "um",
    "uma", "umas", "uns", "vos", "vós"
]

def contem_stop_word(texto):
    """
    Verifica se o texto contém alguma stop word.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        tuple: (bool, stop_word, posição) - Indica se contém stop word, qual e sua posição.
    """
    palavras = texto.lower().split()
    stop_words_encontradas = []
    
    for i, palavra in enumerate(palavras):
        if palavra in STOP_WORDS:
            stop_words_encontradas.append((palavra, i))
    
    if stop_words_encontradas:
        stop_word, posicao = random.choice(stop_words_encontradas)
        return True, stop_word, posicao
    
    return False, "", -1

def aplicar_regra(texto):
    """
    Substitui uma stop word aleatória por outra stop word aleatória.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com uma stop word substituída.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Verificar se o texto contém alguma stop word
    contem, stop_word, posicao = contem_stop_word(texto)
    
    if not contem:
        return texto  # Não há stop words para substituir
    
    # Escolher uma stop word aleatória diferente da atual
    outras_stop_words = [sw for sw in STOP_WORDS if sw != stop_word]
    if outras_stop_words:
        nova_stop_word = random.choice(outras_stop_words)
        
        # Substituir a stop word
        palavras = texto.split()
        palavras[posicao] = nova_stop_word
        nome_modificado = " ".join(palavras)
        
        logger.info(f"Regra 'replace_stop_word' aplicada: '{texto}' -> '{nome_modificado}'")
        return nome_modificado
    
    return texto

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes que contenham stop words,
    ideais para a regra 'replace_stop_word'.
    """
    # Criar condições para cada stop word
    should_conditions = []
    for stop_word in STOP_WORDS:
        should_conditions.append({
            "match_phrase": {
                "nome": f" {stop_word} "  # Espaços para garantir que é uma palavra isolada
            }
        })
    
    return {
        "query": {
            "bool": {
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
