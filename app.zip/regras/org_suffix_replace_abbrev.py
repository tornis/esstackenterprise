"""
Regra para substituir abreviações comumente usadas como sufixos em nomes de organizações.
"""
import re
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Lista de abreviações comuns para organizações
ABREVIACOES_SUFIXOS = [
    "Ltda.", "Ltd.", "S.A.", "S/A", "Inc.", "Corp.", "Cia.", "Co.",
    "ME", "EPP", "Eireli", "Emp.", "Ent.", "Int.", "Tech", "Serv.",
    "Ind.", "Com.", "Adm.", "Dist.", "Transp.", "Consult.", "Assoc."
]

def contem_abreviacao(texto):
    """
    Verifica se o texto contém alguma abreviação conhecida.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        tuple: (bool, abreviação, posição) - Indica se contém abreviação, qual e sua posição.
    """
    for abrev in ABREVIACOES_SUFIXOS:
        # Verificar se a abreviação está no final do texto
        if texto.endswith(f" {abrev}"):
            return True, abrev, len(texto) - len(abrev) - 1
        
        # Verificar se a abreviação está em qualquer parte do texto
        posicao = texto.find(f" {abrev} ")
        if posicao != -1:
            return True, abrev, posicao + 1
    
    return False, "", -1

def aplicar_regra(texto):
    """
    Substitui abreviações comumente usadas como sufixos em nomes de organizações.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com abreviações substituídas.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Verificar se o texto contém alguma abreviação conhecida
    contem, abrev, posicao = contem_abreviacao(texto)
    
    if not contem:
        return texto  # Não há abreviações para substituir
    
    # Escolher uma abreviação aleatória diferente da atual
    outras_abrevs = [a for a in ABREVIACOES_SUFIXOS if a != abrev]
    if outras_abrevs:
        nova_abrev = random.choice(outras_abrevs)
        
        # Substituir a abreviação
        if posicao >= 0:
            nome_modificado = texto[:posicao] + nova_abrev + texto[posicao + len(abrev):]
            logger.info(f"Regra 'org_suffix_replace_abbrev' aplicada: '{texto}' -> '{nome_modificado}'")
            return nome_modificado
    
    return texto

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes de organizações que contenham abreviações conhecidas,
    ideais para a regra 'org_suffix_replace_abbrev'.
    """
    # Criar condições para cada abreviação
    should_conditions = []
    for abrev in ABREVIACOES_SUFIXOS:
        should_conditions.append({
            "match_phrase": {
                "nome": abrev
            }
        })
    
    return {
        "query": {
            "bool": {
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
