"""
Módulo para a regra remove_stop_word (remove uma stop word selecionada aleatoriamente)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

# Lista de stop words em português
STOP_WORDS = [
    'a', 'ao', 'aos', 'aquela', 'aquelas', 'aquele', 'aqueles', 'aquilo', 'as', 'até',
    'com', 'como', 'da', 'das', 'de', 'dela', 'delas', 'dele', 'deles', 'depois',
    'do', 'dos', 'e', 'ela', 'elas', 'ele', 'eles', 'em', 'entre', 'era', 'eram',
    'essa', 'essas', 'esse', 'esses', 'esta', 'estas', 'este', 'estes', 'eu',
    'foi', 'foram', 'fosse', 'fossem', 'há', 'isso', 'isto', 'já', 'lhe', 'lhes',
    'mais', 'mas', 'me', 'mesmo', 'meu', 'meus', 'minha', 'minhas', 'muito', 'muitos',
    'na', 'nas', 'não', 'no', 'nos', 'nossa', 'nossas', 'nosso', 'nossos', 'num',
    'numa', 'o', 'os', 'ou', 'para', 'pela', 'pelas', 'pelo', 'pelos', 'por',
    'qual', 'quando', 'que', 'quem', 'são', 'se', 'seja', 'sejam', 'sem', 'seu',
    'seus', 'só', 'sua', 'suas', 'também', 'te', 'tem', 'têm', 'teu', 'teus',
    'tu', 'tua', 'tuas', 'um', 'uma', 'umas', 'uns', 'você', 'vocês', 'vos', 'vosso', 'vossos'
]

def aplicar_regra(texto):
    """
    Remove uma stop word selecionada aleatoriamente do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto sem a stop word selecionada
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto or len(texto) == 0:
        return texto
    
    # Dividir o texto em palavras
    palavras = texto.split()
    
    # Encontrar todas as stop words no texto
    indices_stop_words = []
    for i, palavra in enumerate(palavras):
        palavra_limpa = palavra.lower().strip('.,;:()[]{}')
        if palavra_limpa in STOP_WORDS:
            indices_stop_words.append(i)
    
    # Se não houver stop words, retornar o texto original
    if not indices_stop_words:
        return texto
    
    # Escolher aleatoriamente uma stop word para remover
    indice_remover = random.choice(indices_stop_words)
    
    # Remover a stop word escolhida
    palavras_resultantes = palavras[:indice_remover] + palavras[indice_remover + 1:]
    
    # Juntar as palavras restantes e retornar
    return " ".join(palavras_resultantes)


# Funções para busca de amostras

def construir_query_remove_stop_word(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham stop words.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Criar cláusulas should para cada stop word
    should_clauses = []
    for stop_word in STOP_WORDS:
        should_clauses.append({
            "match_phrase": {
                "nome": f" {stop_word} "  # Espaços para garantir que é uma palavra completa
            }
        })
    
    # Para remove_stop_word, queremos nomes que contenham pelo menos uma stop word
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": should_clauses,
                "minimum_should_match": 1
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'remove_stop_word': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def encontrar_stop_words(texto):
    """
    Encontra todas as stop words em um texto.
    
    Args:
        texto (str): O texto a ser analisado
        
    Returns:
        list: Lista de tuplas (índice, stop_word) das stop words encontradas
    """
    palavras = texto.split()
    stop_words_encontradas = []
    
    for i, palavra in enumerate(palavras):
        palavra_limpa = palavra.lower().strip('.,;:()[]{}')
        if palavra_limpa in STOP_WORDS:
            stop_words_encontradas.append((i, palavra))
    
    return stop_words_encontradas


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham stop words para a regra remove_stop_word.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'remove_stop_word'")
        
        # Construir a query para remove_stop_word
        query = construir_query_remove_stop_word(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Encontrar stop words no nome
                stop_words = encontrar_stop_words(nome)
                
                # Se encontrou stop words, adicionar à lista de nomes encontrados
                if stop_words:
                    # Escolher uma stop word aleatória para simular a remoção
                    indice_remover, stop_word = random.choice(stop_words)
                    
                    # Dividir o texto em palavras
                    palavras = nome.split()
                    
                    # Criar o nome sem a stop word escolhida
                    nome_modificado = " ".join(palavras[:indice_remover] + palavras[indice_remover + 1:])
                    
                    # Adicionar metadados adicionais
                    hit['_source']['stop_word_removida'] = stop_word
                    hit['_source']['indice_stop_word'] = indice_remover
                    hit['_source']['nome_modificado'] = nome_modificado
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para remove_stop_word: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes adequados para a regra 'remove_stop_word'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'remove_stop_word'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'remove_stop_word'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
