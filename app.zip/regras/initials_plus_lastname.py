"""
Regra para reduzir todos os primeiros e médios nomes a iniciais e prefixá-los ao sobrenome.
"""
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

def aplicar_regra(texto):
    """
    Reduz todos os primeiros e médios nomes a iniciais e os prefixa ao sobrenome.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com os primeiros e médios nomes reduzidos a iniciais e prefixados ao sobrenome.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    if len(palavras) <= 1:
        return texto  # Não há o que modificar se só há uma palavra
    
    # Considerar a última palavra como sobrenome
    sobrenome = palavras[-1]
    
    # Extrair iniciais dos primeiros e médios nomes
    iniciais = ""
    for palavra in palavras[:-1]:
        # Ignorar preposições comuns
        if palavra.lower() not in ["de", "da", "do", "das", "dos"]:
            iniciais += palavra[0]
    
    # Juntar as iniciais ao sobrenome (sem espaço)
    nome_modificado = f"{iniciais}{sobrenome}"
    
    logger.info(f"Regra 'initials_plus_lastname' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes com múltiplas palavras,
    ideais para a regra 'initials_plus_lastname'.
    """
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.split(' ').length > 2",
                                "lang": "painless"
                            }
                        }
                    }
                ],
                "must_not": [
                    {
                        "regexp": {
                            "nome": "[A-Z][A-Z]+[A-Za-z]+"
                        }
                    }
                ]
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match": {
                "nome.keyword": nome_modificado
            }
        }
    }
    
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
