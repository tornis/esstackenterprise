"""
Regra para converter dígitos em suas palavras correspondentes em nomes de organizações.
"""
import re
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Dicionário de dígitos e suas representações em palavras
DIGITOS_PALAVRAS = {
    "0": "zero",
    "1": "um",
    "2": "dois",
    "3": "três",
    "4": "quatro",
    "5": "cinco",
    "6": "seis",
    "7": "sete",
    "8": "oito",
    "9": "nove",
    "10": "dez",
    "11": "onze",
    "12": "doze",
    "13": "treze",
    "14": "quatorze",
    "15": "quinze",
    "16": "dezesseis",
    "17": "dezessete",
    "18": "dezoito",
    "19": "dezenove",
    "20": "vinte",
    "30": "trinta",
    "40": "quarenta",
    "50": "cinquenta",
    "60": "sessenta",
    "70": "setenta",
    "80": "oitenta",
    "90": "noventa",
    "100": "cem",
    "200": "duzentos",
    "300": "trezentos",
    "400": "quatrocentos",
    "500": "quinhentos",
    "600": "seiscentos",
    "700": "setecentos",
    "800": "oitocentos",
    "900": "novecentos",
    "1000": "mil",
    "1000000": "milhão"
}

def aplicar_regra(texto):
    """
    Converte dígitos em suas palavras correspondentes em nomes de organizações.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com dígitos convertidos em palavras.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Função para substituir números por palavras
    def substituir_numero(match):
        numero = match.group(0)
        
        # Verificar se o número está no dicionário
        if numero in DIGITOS_PALAVRAS:
            return DIGITOS_PALAVRAS[numero]
        
        # Para números maiores, tentar converter dígito a dígito
        if len(numero) > 1:
            resultado = []
            for digito in numero:
                if digito in DIGITOS_PALAVRAS:
                    resultado.append(DIGITOS_PALAVRAS[digito])
                else:
                    resultado.append(digito)
            return " ".join(resultado)
        
        return numero
    
    # Substituir números por palavras
    nome_modificado = re.sub(r'\b\d+\b', substituir_numero, texto)
    
    if nome_modificado != texto:
        logger.info(f"Regra 'org_name_num2alpha' aplicada: '{texto}' -> '{nome_modificado}'")
    
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes de organizações que contenham dígitos,
    ideais para a regra 'org_name_num2alpha'.
    """
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "regexp": {
                            "nome": ".*\\d+.*"
                        }
                    }
                ]
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
