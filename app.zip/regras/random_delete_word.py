"""
Módulo para a regra random_delete_word (exclui uma palavra aleatória do texto do campo)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Exclui uma palavra aleatória do texto do campo.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com uma palavra aleatória removida
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto or len(texto) == 0:
        return texto
    
    # Dividir o texto em palavras
    palavras = texto.split()
    
    # Se houver apenas uma palavra, retornar texto vazio
    if len(palavras) <= 1:
        return ""
    
    # Escolher aleatoriamente uma palavra para remover
    indice_remover = random.randint(0, len(palavras) - 1)
    
    # Remover a palavra escolhida
    palavras_resultantes = palavras[:indice_remover] + palavras[indice_remover + 1:]
    
    # Juntar as palavras restantes e retornar
    return " ".join(palavras_resultantes)


# Funções para busca de amostras

def construir_query_random_delete_word(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham pelo menos duas palavras para a regra random_delete_word.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para random_delete_word, queremos nomes que contenham pelo menos duas palavras
    query = {
        "size": max_samples,
        "query": {
            "match_all": {}
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'random_delete_word': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham pelo menos duas palavras para a regra random_delete_word.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'random_delete_word'")
        
        # Construir a query para random_delete_word
        query = construir_query_random_delete_word(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome tem pelo menos duas palavras
                palavras = nome.split()
                if len(palavras) >= 2:
                    # Escolher aleatoriamente uma palavra para simular a remoção
                    indice_remover = random.randint(0, len(palavras) - 1)
                    palavra_removida = palavras[indice_remover]
                    
                    # Criar o nome sem a palavra escolhida
                    nome_modificado = " ".join(palavras[:indice_remover] + palavras[indice_remover + 1:])
                    
                    # Adicionar metadados adicionais
                    hit['_source']['palavra_removida'] = palavra_removida
                    hit['_source']['indice_palavra_removida'] = indice_remover
                    hit['_source']['nome_modificado'] = nome_modificado
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para random_delete_word: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes adequados para a regra 'random_delete_word'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'random_delete_word'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'random_delete_word'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
