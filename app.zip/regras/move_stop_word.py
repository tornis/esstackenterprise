"""
Regra para mover uma stop word selecionada aleatoriamente para outra posição no nome.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Lista de stop words em português
STOP_WORDS = [
    "a", "ao", "aos", "aquela", "aquelas", "aquele", "aqueles", "aquilo", "as", "até",
    "com", "como", "da", "das", "de", "dela", "delas", "dele", "deles", "depois",
    "do", "dos", "e", "ela", "elas", "ele", "eles", "em", "entre", "era",
    "eram", "éramos", "essa", "essas", "esse", "esses", "esta", "estas", "este", "estes",
    "eu", "foi", "fomos", "for", "foram", "fosse", "fossem", "fui", "há", "isso",
    "isto", "já", "lhe", "lhes", "mais", "mas", "me", "mesmo", "meu", "meus",
    "minha", "minhas", "muito", "na", "não", "nas", "nem", "no", "nos", "nós",
    "nossa", "nossas", "nosso", "nossos", "num", "numa", "o", "os", "ou", "para",
    "pela", "pelas", "pelo", "pelos", "por", "qual", "quando", "que", "quem", "se",
    "sem", "seu", "seus", "só", "somos", "sou", "sua", "suas", "também", "te",
    "tem", "tém", "temos", "tenho", "teu", "teus", "tu", "tua", "tuas", "um",
    "uma", "umas", "uns", "vos", "vós"
]

def contem_stop_word(texto):
    """
    Verifica se o texto contém alguma stop word e retorna uma lista de todas as stop words encontradas
    com suas posições.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        list: Lista de tuplas (stop_word, posição) com as stop words encontradas.
    """
    palavras = texto.lower().split()
    stop_words_encontradas = []
    
    for i, palavra in enumerate(palavras):
        if palavra in STOP_WORDS:
            stop_words_encontradas.append((palavra, i))
    
    return stop_words_encontradas

def aplicar_regra(texto):
    """
    Move uma stop word selecionada aleatoriamente para outra posição no nome.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com a stop word movida.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Verificar se o texto contém alguma stop word
    stop_words_encontradas = contem_stop_word(texto)
    
    if not stop_words_encontradas:
        return texto  # Não há stop words para mover
    
    palavras = texto.split()
    
    # Selecionar aleatoriamente uma stop word para mover
    stop_word, posicao_original = random.choice(stop_words_encontradas)
    
    # Determinar uma nova posição aleatória diferente da original
    posicoes_possiveis = list(range(len(palavras)))
    posicoes_possiveis.remove(posicao_original)
    
    if not posicoes_possiveis:
        return texto  # Não há outras posições possíveis
    
    nova_posicao = random.choice(posicoes_possiveis)
    
    # Remover a stop word da posição original
    stop_word_texto = palavras.pop(posicao_original)
    
    # Inserir a stop word na nova posição
    palavras.insert(nova_posicao, stop_word_texto)
    
    nome_modificado = " ".join(palavras)
    
    logger.info(f"Regra 'move_stop_word' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes que contenham stop words,
    ideais para a regra 'move_stop_word'.
    """
    # Criar condições para cada stop word
    should_conditions = []
    for stop_word in STOP_WORDS:
        should_conditions.append({
            "match_phrase": {
                "nome": f" {stop_word} "  # Espaços para garantir que é uma palavra isolada
            }
        })
    
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.split(' ').length > 3",
                                "lang": "painless"
                            }
                        }
                    }
                ],
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
