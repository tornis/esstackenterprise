"""
Módulo para a regra replace_dbl2sgl (substituição de letras duplicadas por letras simples)
"""
import re
import random
import logging
import json
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Substitui uma ocorrência de letra duplicada por uma única ocorrência em cada palavra do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com letras duplicadas substituídas por uma única ocorrência em cada palavra
    """
    # Processar cada palavra separadamente
    palavras = texto.split()
    palavras_processadas = [reduzir_letra_duplicada(palavra) for palavra in palavras]
    return ' '.join(palavras_processadas)

def reduzir_letra_duplicada(texto):
    """
    Encontra letras duplicadas no texto e substitui todas as duplicações por uma única ocorrência.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com todas as letras duplicadas substituídas por uma única ocorrência
    """
    # Encontrar letras duplicadas
    duplicadas = re.finditer(r'(.)\1+', texto)
    duplicadas_list = list(duplicadas)
    
    if not duplicadas_list:
        return texto
    
    # Processar todas as duplicações (começando do final para não afetar os índices)
    resultado = texto
    for match in sorted(duplicadas_list, key=lambda m: m.span()[0], reverse=True):
        start, end = match.span()
        char = resultado[start]
        
        # Substituir por uma única ocorrência
        resultado = resultado[:start] + char + resultado[end:]
    
    return resultado

def contem_letras_duplicadas(texto):
    """
    Verifica se um texto contém letras duplicadas.
    
    Args:
        texto (str): O texto a ser verificado
        
    Returns:
        bool: True se o texto contém letras duplicadas, False caso contrário
    """
    # Verificar se há qualquer letra duplicada (duas letras iguais consecutivas)
    return bool(re.search(r'([a-zA-Z])\1', texto))

def extrair_letras_duplicadas(texto):
    """
    Extrai as letras duplicadas de um texto.
    
    Args:
        texto (str): O texto do qual extrair as letras duplicadas
        
    Returns:
        list: Uma lista contendo as letras duplicadas encontradas no texto
    """
    # Encontrar todas as letras duplicadas
    duplicadas = re.findall(r'([a-zA-Z])\1+', texto)
    return duplicadas


# Funções para busca de amostras

def construir_query_replace_dbl2sgl(texto_base, max_samples=50, fuzziness="AUTO", operator="or"):
    """
    Constrói uma query específica para a regra replace_dbl2sgl.
    Esta query busca nomes que contenham letras duplicadas.
    
    Args:
        texto_base (str): O texto base para a busca
        max_samples (int): Número máximo de amostras a retornar
        fuzziness (str): Nível de fuzziness para a busca
        operator (str): Operador para a busca ("and" ou "or")
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para replace_dbl2sgl, queremos nomes que contenham letras duplicadas
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": [
                    # Buscar nomes que contenham letras duplicadas usando regexp
                    {
                        "regexp": {
                            "nome": ".*([a-zA-Z])\\1+.*"  # Expressão regular para encontrar letras duplicadas
                        }
                    },
                    # Adicionar também buscas específicas para letras duplicadas comuns
                    {"wildcard": {"nome": "*aa*"}},
                    {"wildcard": {"nome": "*bb*"}},
                    {"wildcard": {"nome": "*cc*"}},
                    {"wildcard": {"nome": "*dd*"}},
                    {"wildcard": {"nome": "*ee*"}},
                    {"wildcard": {"nome": "*ff*"}},
                    {"wildcard": {"nome": "*gg*"}},
                    {"wildcard": {"nome": "*hh*"}},
                    {"wildcard": {"nome": "*ii*"}},
                    {"wildcard": {"nome": "*jj*"}},
                    {"wildcard": {"nome": "*kk*"}},
                    {"wildcard": {"nome": "*ll*"}},
                    {"wildcard": {"nome": "*mm*"}},
                    {"wildcard": {"nome": "*nn*"}},
                    {"wildcard": {"nome": "*oo*"}},
                    {"wildcard": {"nome": "*pp*"}},
                    {"wildcard": {"nome": "*qq*"}},
                    {"wildcard": {"nome": "*rr*"}},
                    {"wildcard": {"nome": "*ss*"}},
                    {"wildcard": {"nome": "*tt*"}},
                    {"wildcard": {"nome": "*uu*"}},
                    {"wildcard": {"nome": "*vv*"}},
                    {"wildcard": {"nome": "*ww*"}},
                    {"wildcard": {"nome": "*xx*"}},
                    {"wildcard": {"nome": "*yy*"}},
                    {"wildcard": {"nome": "*zz*"}}
                ],
                "minimum_should_match": 1
            }
        }
    }
    
    logger.info(f"Query DSL construída para regra 'replace_dbl2sgl': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham letras duplicadas para a regra replace_dbl2sgl.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'replace_dbl2sgl'")
        
        # Construir a query específica para replace_dbl2sgl
        query = construir_query_replace_dbl2sgl(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome realmente contém letras duplicadas
                if contem_letras_duplicadas(nome):
                    # Adicionar informações sobre as letras duplicadas encontradas
                    letras_duplicadas = extrair_letras_duplicadas(nome)
                    hit['_source']['letras_duplicadas'] = letras_duplicadas
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome com letras duplicadas encontrado: {nome} (letras: {letras_duplicadas})")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'replace_dbl2sgl'")
        
        # Ordenar os resultados para priorizar nomes com mais letras duplicadas
        if nomes_encontrados:
            # Primeiro, garantir que todos os nomes tenham a propriedade letras_duplicadas
            for nome_doc in nomes_encontrados:
                if 'letras_duplicadas' not in nome_doc:
                    nome = nome_doc.get('nome', '')
                    nome_doc['letras_duplicadas'] = extrair_letras_duplicadas(nome)
                    
            # Ordenar por quantidade de letras duplicadas (mais duplicações primeiro)
            nomes_encontrados.sort(key=lambda x: len(re.findall(r'([a-zA-Z])\1+', x.get('nome', ''))), reverse=True)
            logger.info(f"Nomes ordenados por quantidade de letras duplicadas")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'replace_dbl2sgl'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome com letras duplicadas foi encontrado para a regra 'replace_dbl2sgl'. "
                            f"Verifique se existem nomes com letras duplicadas no índice.")
            else:
                logger.info(f"Encontrados {len(nomes_encontrados)} nomes com letras duplicadas para a regra 'replace_dbl2sgl'.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
