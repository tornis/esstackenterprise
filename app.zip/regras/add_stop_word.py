"""
Regra para adicionar uma palavra de parada (stop word) aleatória a um nome se não houver nenhuma presente.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Lista de palavras de parada em português
STOP_WORDS = [
    "a", "ao", "aos", "aquela", "aquelas", "aquele", "aqueles", "aquilo", "as", "até",
    "com", "como", "da", "das", "de", "dela", "delas", "dele", "deles", "depois",
    "do", "dos", "e", "ela", "elas", "ele", "eles", "em", "entre", "era",
    "eram", "éramos", "essa", "essas", "esse", "esses", "esta", "estas", "este", "estes",
    "eu", "foi", "fomos", "for", "foram", "fosse", "fossem", "há", "isso", "isto",
    "já", "lhe", "lhes", "mais", "mas", "me", "mesmo", "meu", "meus", "minha",
    "minhas", "na", "nas", "nem", "no", "nos", "nós", "nossa", "nossas", "nosso",
    "nossos", "num", "numa", "o", "os", "ou", "para", "pela", "pelas", "pelo",
    "pelos", "por", "qual", "quando", "que", "quem", "se", "sem", "seu", "seus",
    "sua", "suas", "são", "só", "também", "te", "teu", "teus", "tu", "tua",
    "tuas", "um", "uma", "você", "vocês", "vos", "à", "às"
]

def contem_stop_word(texto):
    """
    Verifica se o texto contém alguma palavra de parada.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        bool: True se o texto contém pelo menos uma palavra de parada, False caso contrário.
    """
    palavras = texto.lower().split()
    return any(palavra in STOP_WORDS for palavra in palavras)

def aplicar_regra(texto):
    """
    Adiciona uma palavra de parada aleatória a um nome se não houver nenhuma presente.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com uma palavra de parada adicionada, ou o nome original se já contiver uma palavra de parada.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Se já contém uma palavra de parada, retorna o texto original
    if contem_stop_word(texto):
        return texto
    
    # Escolher uma palavra de parada aleatória
    stop_word = random.choice(STOP_WORDS)
    
    # Escolher aleatoriamente onde inserir a palavra de parada
    palavras = texto.split()
    if not palavras:
        return texto
    
    posicao = random.randint(0, len(palavras))
    
    # Inserir a palavra de parada na posição escolhida
    palavras.insert(posicao, stop_word)
    nome_modificado = " ".join(palavras)
    
    logger.info(f"Regra 'add_stop_word' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes que não contenham palavras de parada,
    ideais para a regra 'add_stop_word'.
    """
    # Criar uma condição para cada palavra de parada
    must_not_conditions = []
    for stop_word in STOP_WORDS:
        must_not_conditions.append({
            "match_phrase": {
                "nome": stop_word
            }
        })
    
    return {
        "query": {
            "bool": {
                "must_not": must_not_conditions
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
