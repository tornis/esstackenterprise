"""
Módulo para a regra move_special_char (mover um caractere especial não alfanumérico para uma posição aleatória dentro do nome)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

# Lista de caracteres especiais não alfanuméricos comuns
CARACTERES_ESPECIAIS = ['!', '@', '#', '$', '%', '&', '*', '+', '=', '?', '^', '~', '|', '\\', '/', '<', '>', '{', '}', '[', ']', ';', ':', "'", '"', ',', '.', '-', '_', '(', ')', ' ']

def aplicar_regra(texto):
    """
    Move um caractere especial não alfanumérico para uma posição aleatória dentro do texto.
    Se não houver caractere especial, seleciona um aleatoriamente e o adiciona em posição aleatória.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com o caractere especial movido ou adicionado
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Encontrar todos os caracteres especiais no texto
    caracteres_especiais_encontrados = [c for c in texto if c in CARACTERES_ESPECIAIS]
    
    # Se encontrou caracteres especiais, escolher um aleatoriamente e removê-lo
    if caracteres_especiais_encontrados:
        char_especial = random.choice(caracteres_especiais_encontrados)
        texto = texto.replace(char_especial, "", 1)  # Remove apenas a primeira ocorrência
    else:
        # Se não encontrou, escolher um caractere especial aleatório da lista
        char_especial = random.choice(CARACTERES_ESPECIAIS)
    
    # Escolher uma posição aleatória para inserir o caractere especial
    posicao = random.randint(0, len(texto))
    
    # Inserir o caractere especial na posição escolhida
    texto_modificado = texto[:posicao] + char_especial + texto[posicao:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_move_special_char(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham caracteres especiais para a regra move_special_char.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para move_special_char, queremos nomes que contenham caracteres especiais
    # Construir uma lista de condições "should" para cada caractere especial
    should_conditions = []
    for char in CARACTERES_ESPECIAIS:
        # Escapar caracteres especiais para wildcard
        escaped_char = char
        if char in ['*', '?', '\\']:
            escaped_char = '\\' + char
            
        should_conditions.append({
            "wildcard": {
                "nome": f"*{escaped_char}*"  # Buscar nomes que contenham o caractere especial
            }
        })
    
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": should_conditions,
                "minimum_should_match": 1
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'move_special_char': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham caracteres especiais para a regra move_special_char.
    Se não encontrar nomes suficientes com caracteres especiais, complementa com nomes aleatórios.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes com caracteres especiais do índice {MAIN_INDEX_NAME} para a regra 'move_special_char'")
        
        # Construir a query para move_special_char
        query = construir_query_move_special_char(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome contém caracteres especiais
                caracteres_especiais_no_nome = [c for c in nome if c in CARACTERES_ESPECIAIS]
                
                if caracteres_especiais_no_nome:
                    # Adicionar metadados adicionais
                    hit['_source']['caracteres_especiais'] = caracteres_especiais_no_nome
                    hit['_source']['posicoes'] = {char: nome.find(char) for char in set(caracteres_especiais_no_nome)}
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para move_special_char: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes com caracteres especiais para a regra 'move_special_char'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'move_special_char'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'move_special_char'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
