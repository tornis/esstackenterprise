"""
Regra para converter palavras que representam números em dígitos em nomes de organizações.
"""
import re
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Dicionário de palavras numéricas e seus equivalentes em dígitos
PALAVRAS_NUMERICAS = {
    "zero": "0",
    "um": "1", "uma": "1",
    "dois": "2", "duas": "2",
    "três": "3", "tres": "3",
    "quatro": "4",
    "cinco": "5",
    "seis": "6",
    "sete": "7",
    "oito": "8",
    "nove": "9",
    "dez": "10",
    "onze": "11",
    "doze": "12",
    "treze": "13",
    "quatorze": "14", "catorze": "14",
    "quinze": "15",
    "dezesseis": "16", "dezasseis": "16",
    "dezessete": "17", "dezassete": "17",
    "dezoito": "18",
    "dezenove": "19", "dezanove": "19",
    "vinte": "20",
    "trinta": "30",
    "quarenta": "40",
    "cinquenta": "50",
    "sessenta": "60",
    "setenta": "70",
    "oitenta": "80",
    "noventa": "90",
    "cem": "100", "cento": "100",
    "duzentos": "200", "duzentas": "200",
    "trezentos": "300", "trezentas": "300",
    "quatrocentos": "400", "quatrocentas": "400",
    "quinhentos": "500", "quinhentas": "500",
    "seiscentos": "600", "seiscentas": "600",
    "setecentos": "700", "setecentas": "700",
    "oitocentos": "800", "oitocentas": "800",
    "novecentos": "900", "novecentas": "900",
    "mil": "1000",
    "milhão": "1000000", "milhao": "1000000",
    "milhões": "1000000", "milhoes": "1000000",
    "bilhão": "1000000000", "bilhao": "1000000000",
    "bilhões": "1000000000", "bilhoes": "1000000000"
}

def aplicar_regra(texto):
    """
    Converte palavras que representam números em dígitos em nomes de organizações.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com palavras numéricas convertidas em dígitos.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    resultado = []
    
    for palavra in palavras:
        palavra_lower = palavra.lower()
        
        # Verificar se a palavra está no dicionário de palavras numéricas
        if palavra_lower in PALAVRAS_NUMERICAS:
            resultado.append(PALAVRAS_NUMERICAS[palavra_lower])
        else:
            resultado.append(palavra)
    
    nome_modificado = " ".join(resultado)
    
    if nome_modificado != texto:
        logger.info(f"Regra 'org_name_alpha2num' aplicada: '{texto}' -> '{nome_modificado}'")
    
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes de organizações que contenham palavras numéricas,
    ideais para a regra 'org_name_alpha2num'.
    """
    # Criar uma lista de palavras numéricas para buscar
    palavras_numericas = list(PALAVRAS_NUMERICAS.keys())
    
    # Criar condições para cada palavra numérica
    should_conditions = []
    for palavra in palavras_numericas:
        should_conditions.append({
            "match_phrase": {
                "nome": palavra
            }
        })
    
    return {
        "query": {
            "bool": {
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
