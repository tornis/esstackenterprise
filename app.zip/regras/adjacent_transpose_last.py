"""
Módulo para a regra adjacent_transpose_last (transpõe os dois últimos caracteres do nome)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Transpõe os dois últimos caracteres do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com os dois últimos caracteres transpostos
    """
    return transpor_caracteres_adjacentes_fim(texto)

def transpor_caracteres_adjacentes_fim(texto):
    """
    Transpõe os dois últimos caracteres do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com os dois últimos caracteres transpostos
    """
    if len(texto) < 2:
        return texto
    
    return texto[:-2] + texto[-1] + texto[-2]


# Funções para busca de amostras

def construir_query_adjacent_transpose_last(texto_base="", max_samples=50):
    """
    Constrói uma query específica para a regra adjacent_transpose_last.
    Esta query busca nomes que tenham pelo menos 2 caracteres para permitir a transposição dos últimos caracteres.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para adjacent_transpose_last, queremos nomes que tenham pelo menos 2 caracteres
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "range": {
                            "nome.keyword": {
                                "gte": "AA",  # Garante que o nome tenha pelo menos 2 caracteres
                            }
                        }
                    }
                ],
                "must_not": [
                    {
                        "term": {
                            "nome.keyword": ""
                        }
                    }
                ]
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'adjacent_transpose_last': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes adequados para a regra adjacent_transpose_last.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'adjacent_transpose_last'")
        
        # Construir a query para adjacent_transpose_last
        query = construir_query_adjacent_transpose_last(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome tem pelo menos 2 caracteres
                if nome and len(nome) >= 2:
                    # Adicionar metadados adicionais
                    hit['_source']['penultimo_caractere'] = nome[-2]
                    hit['_source']['ultimo_caractere'] = nome[-1]
                    hit['_source']['transposicao'] = nome[:-2] + nome[-1] + nome[-2]
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para adjacent_transpose_last: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes adequados para a regra 'adjacent_transpose_last'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'adjacent_transpose_last'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'adjacent_transpose_last'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
