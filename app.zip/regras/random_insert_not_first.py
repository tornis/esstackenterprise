"""
Módulo para a regra random_insert_not_first (inserir um caractere alfabético aleatório em qualquer lugar da palavra, exceto no início)
"""
import random
import string
import logging
import json
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Insere um caractere alfabético aleatório em uma posição aleatória de cada palavra, exceto no início.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com um caractere alfabético inserido em uma posição aleatória de cada palavra (exceto no início)
    """
    palavras = texto.split()
    
    # Se não houver palavras, retornar o texto original
    if not palavras:
        return texto
    
    palavras_modificadas = []
    for palavra in palavras:
        # Se a palavra tem apenas um caractere ou está vazia, não podemos inserir depois do primeiro caractere
        if len(palavra) <= 1:
            palavras_modificadas.append(palavra)
            continue
        
        # Escolher um caractere alfabético aleatório
        caractere_aleatorio = random.choice(string.ascii_letters)
        
        # Escolher uma posição aleatória na palavra para inserir o caractere (exceto no início)
        # Posição 1 significa após o primeiro caractere
        posicao = random.randint(1, len(palavra))
        
        # Inserir o caractere na posição escolhida
        palavra_modificada = palavra[:posicao] + caractere_aleatorio + palavra[posicao:]
        palavras_modificadas.append(palavra_modificada)
    
    # Juntar as palavras novamente
    return ' '.join(palavras_modificadas)


# Funções para busca de amostras

def construir_query_random_insert_not_first(texto_base, max_samples=50):
    """
    Constrói uma query para buscar nomes aleatórios para a regra random_insert_not_first.
    Esta query usa match_all para buscar nomes aleatórios.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta regra)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para random_insert_not_first, usamos match_all para buscar nomes aleatórios
    query = {
        "size": max_samples,
        "query": {
            "match_all": {}
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'random_insert_not_first': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes aleatórios para a regra random_insert_not_first.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta regra)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes aleatórios do índice {MAIN_INDEX_NAME} para a regra 'random_insert_not_first'")
        
        # Construir a query para random_insert_not_first
        query = construir_query_random_insert_not_first(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome tem pelo menos uma palavra com mais de um caractere
                palavras = nome.split()
                palavras_validas = [p for p in palavras if len(p) > 1]
                if palavras_validas:
                    # Adicionar metadados adicionais
                    hit['_source']['caractere_aleatorio'] = random.choice(string.ascii_letters)  # Apenas para referência
                    hit['_source']['palavras_validas'] = len(palavras_validas)
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para random_insert_not_first: {nome} ({len(palavras_validas)} palavras válidas)")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'random_insert_not_first'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'random_insert_not_first'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'random_insert_not_first'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
