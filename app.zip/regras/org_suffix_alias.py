"""
Regra para abreviar ou expandir palavras comumente usadas como sufixos em nomes de organizações.
"""
import re
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Dicionário de sufixos e suas abreviações/expansões
SUFIXOS_ALIAS = {
    # Abreviações -> Formas expandidas
    "Ltda": ["Limitada"],
    "Ltda.": ["Limitada"],
    "Ltd": ["Limited"],
    "Ltd.": ["Limited"],
    "S.A.": ["Sociedade Anônima"],
    "S/A": ["Sociedade Anônima"],
    "Inc": ["Incorporated"],
    "Inc.": ["Incorporated"],
    "Corp": ["Corporation"],
    "Corp.": ["Corporation"],
    "Cia": ["Companhia"],
    "Cia.": ["Companhia"],
    "Co": ["Company"],
    "Co.": ["Company"],
    
    # Formas expandidas -> Abreviações
    "Limitada": ["Ltda.", "Ltda"],
    "Limited": ["Ltd.", "Ltd"],
    "Sociedade Anônima": ["S.A.", "S/A"],
    "Sociedade Anonima": ["S.A.", "S/A"],
    "Incorporated": ["Inc.", "Inc"],
    "Corporation": ["Corp.", "Corp"],
    "Companhia": ["Cia.", "Cia"],
    "Company": ["Co.", "Co"],
    "Empresa Individual de Responsabilidade Limitada": ["Eireli"],
    "Microempresa": ["ME"],
    "Empresa de Pequeno Porte": ["EPP"],
    "Grupo": ["Group"],
    "Group": ["Grupo"],
    "Holdings": ["Holding"],
    "Holding": ["Holdings"],
    "Empreendimentos": ["Emp."],
    "Enterprises": ["Ent."],
    "International": ["Int."],
    "Internacional": ["Int."],
    "Tecnologia": ["Tech"],
    "Technology": ["Tech"],
    "Serviços": ["Serv."],
    "Services": ["Serv."]
}

def contem_sufixo(texto):
    """
    Verifica se o texto contém algum sufixo conhecido.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        tuple: (bool, sufixo, posição) - Indica se contém sufixo, qual sufixo e sua posição.
    """
    for sufixo in SUFIXOS_ALIAS.keys():
        # Verificar se o sufixo está no final do texto
        if texto.endswith(f" {sufixo}"):
            return True, sufixo, len(texto) - len(sufixo) - 1
        
        # Verificar se o sufixo está em qualquer parte do texto
        posicao = texto.find(f" {sufixo} ")
        if posicao != -1:
            return True, sufixo, posicao + 1
    
    return False, "", -1

def aplicar_regra(texto):
    """
    Abrevia ou expande palavras comumente usadas como sufixos em nomes de organizações.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com sufixos abreviados ou expandidos.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Verificar se o texto contém algum sufixo conhecido
    contem, sufixo, posicao = contem_sufixo(texto)
    
    if not contem:
        return texto  # Não há sufixos para modificar
    
    # Escolher uma abreviação/expansão aleatória
    if sufixo in SUFIXOS_ALIAS and SUFIXOS_ALIAS[sufixo]:
        novo_sufixo = random.choice(SUFIXOS_ALIAS[sufixo])
        
        # Substituir o sufixo
        if posicao >= 0:
            nome_modificado = texto[:posicao] + novo_sufixo + texto[posicao + len(sufixo):]
            logger.info(f"Regra 'org_suffix_alias' aplicada: '{texto}' -> '{nome_modificado}'")
            return nome_modificado
    
    return texto

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes de organizações que contenham sufixos conhecidos,
    ideais para a regra 'org_suffix_alias'.
    """
    # Criar uma lista de sufixos para buscar
    sufixos = list(SUFIXOS_ALIAS.keys())
    
    # Criar condições para cada sufixo
    should_conditions = []
    for sufixo in sufixos:
        should_conditions.append({
            "match_phrase": {
                "nome": sufixo
            }
        })
    
    return {
        "query": {
            "bool": {
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
