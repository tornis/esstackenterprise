"""
Módulo para a regra replace_ch_cc (substituir uma ocorrência aleatória das letras CH pelas letras CC)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Substitui uma ocorrência aleatória das letras CH pelas letras CC no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com uma ocorrência das letras CH substituídas por CC
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Encontrar todas as posições da sequência "ch" (maiúscula, minúscula ou mista)
    posicoes_ch = []
    texto_lower = texto.lower()
    
    for i in range(len(texto) - 1):
        if texto_lower[i:i+2] == 'ch':
            posicoes_ch.append(i)
    
    # Se não houver sequência "ch" no texto, retornar o texto original
    if not posicoes_ch:
        return texto
    
    # Escolher uma posição aleatória para substituir
    posicao = random.choice(posicoes_ch)
    
    # Determinar se as letras são maiúsculas ou minúsculas
    if texto[posicao].isupper() and texto[posicao+1].isupper():
        substituto = 'CC'
    elif texto[posicao].isupper() and texto[posicao+1].islower():
        substituto = 'Cc'
    elif texto[posicao].islower() and texto[posicao+1].isupper():
        substituto = 'cC'
    else:
        substituto = 'cc'
    
    # Substituir as letras CH pelas letras CC na posição escolhida
    texto_modificado = texto[:posicao] + substituto + texto[posicao+2:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_replace_ch_cc(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham a sequência "ch" para a regra replace_ch_cc.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para replace_ch_cc, queremos nomes que contenham a sequência "ch" (maiúscula ou minúscula)
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": [
                    {
                        "wildcard": {
                            "nome": "*ch*"  # Nomes que contenham a sequência "ch" minúscula
                        }
                    },
                    {
                        "wildcard": {
                            "nome": "*CH*"  # Nomes que contenham a sequência "CH" maiúscula
                        }
                    },
                    {
                        "wildcard": {
                            "nome": "*Ch*"  # Nomes que contenham a sequência "Ch" mista
                        }
                    },
                    {
                        "wildcard": {
                            "nome": "*cH*"  # Nomes que contenham a sequência "cH" mista
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'replace_ch_cc': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham a sequência "ch" para a regra replace_ch_cc.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes que contenham a sequência 'ch' do índice {MAIN_INDEX_NAME} para a regra 'replace_ch_cc'")
        
        # Construir a query para replace_ch_cc
        query = construir_query_replace_ch_cc(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome contém a sequência "ch" (maiúscula ou minúscula)
                posicoes_ch = []
                nome_lower = nome.lower()
                
                for i in range(len(nome) - 1):
                    if nome_lower[i:i+2] == 'ch':
                        posicoes_ch.append(i)
                
                if posicoes_ch:
                    # Adicionar metadados adicionais
                    hit['_source']['posicoes_ch'] = posicoes_ch
                    hit['_source']['quantidade_ch'] = len(posicoes_ch)
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para replace_ch_cc: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes que contêm a sequência 'ch' para a regra 'replace_ch_cc'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'replace_ch_cc'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'replace_ch_cc'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
