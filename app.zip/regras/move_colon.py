"""
Módulo para a regra move_colon (mover dois pontos para uma posição aleatória dentro do nome)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Move dois pontos (:) para uma posição aleatória dentro do texto.
    Se não houver dois pontos, adiciona em posição aleatória.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com os dois pontos movidos ou adicionados
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Verificar se o texto já contém dois pontos
    colon_encontrado = ":" in texto
    
    # Se encontrou dois pontos, removê-los
    if colon_encontrado:
        texto = texto.replace(":", "", 1)  # Remove apenas a primeira ocorrência
    
    # Escolher uma posição aleatória para inserir os dois pontos
    posicao = random.randint(0, len(texto))
    
    # Inserir os dois pontos na posição escolhida
    texto_modificado = texto[:posicao] + ":" + texto[posicao:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_move_colon(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham dois pontos para a regra move_colon.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para move_colon, queremos nomes que contenham dois pontos
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "wildcard": {
                            "nome": "*:*"  # Buscar nomes que contenham dois pontos
                        }
                    }
                ]
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'move_colon': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham dois pontos para a regra move_colon.
    Se não encontrar nomes suficientes com dois pontos, complementa com nomes aleatórios.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes com dois pontos do índice {MAIN_INDEX_NAME} para a regra 'move_colon'")
        
        # Construir a query para move_colon
        query = construir_query_move_colon(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome contém dois pontos
                if ":" in nome:
                    # Adicionar metadados adicionais
                    hit['_source']['posicao_colon'] = nome.find(":")
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para move_colon: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes com dois pontos para a regra 'move_colon'")
        
    
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'move_colon'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'move_colon'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
