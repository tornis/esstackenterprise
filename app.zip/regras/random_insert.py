"""
Módulo para a regra random_insert (inserir um caractere alfabético aleatório em qualquer lugar do nome)
"""
import random
import string
import logging
import json
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Insere um caractere alfabético aleatório em uma posição aleatória do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com um caractere alfabético inserido em uma posição aleatória
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Escolher um caractere alfabético aleatório
    caractere_aleatorio = random.choice(string.ascii_letters)
    
    # Escolher uma posição aleatória no texto para inserir o caractere
    posicao = random.randint(0, len(texto))
    
    # Inserir o caractere na posição escolhida
    texto_modificado = texto[:posicao] + caractere_aleatorio + texto[posicao:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_random_insert(texto_base, max_samples=50):
    """
    Constrói uma query para buscar nomes aleatórios para a regra random_insert.
    Esta query usa match_all para buscar nomes aleatórios.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta regra)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para random_insert, usamos match_all para buscar nomes aleatórios
    query = {
        "size": max_samples,
        "query": {
            "match_all": {}
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'random_insert': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes aleatórios para a regra random_insert.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta regra)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes aleatórios do índice {MAIN_INDEX_NAME} para a regra 'random_insert'")
        
        # Construir a query para random_insert
        query = construir_query_random_insert(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome não está vazio
                if nome:
                    # Adicionar metadados adicionais
                    hit['_source']['caractere_aleatorio'] = random.choice(string.ascii_letters)  # Apenas para referência
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para random_insert: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'random_insert'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'random_insert'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'random_insert'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
