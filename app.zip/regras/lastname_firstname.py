"""
Regra para mover todos os primeiros e médios nomes para o final do sobrenome.
"""
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

def aplicar_regra(texto):
    """
    Move todos os primeiros e médios nomes para o final do sobrenome.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com os primeiros e médios nomes movidos para o final do sobrenome.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    if len(palavras) <= 1:
        return texto  # Não há o que modificar se só há uma palavra
    
    # Considerar a última palavra como sobrenome
    sobrenome = palavras[-1]
    
    # Obter todos os primeiros e médios nomes
    primeiros_nomes = palavras[:-1]
    
    # Mover os primeiros e médios nomes para o final do sobrenome
    nome_modificado = sobrenome + " " + " ".join(primeiros_nomes)
    
    logger.info(f"Regra 'lastname_firstname' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes com múltiplas palavras,
    ideais para a regra 'lastname_firstname'.
    """
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.split(' ').length > 2",
                                "lang": "painless"
                            }
                        }
                    }
                ]
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    palavras = nome_modificado.split()
    if not palavras:
        return None
    
    # Extrair o sobrenome (primeira palavra) e os primeiros nomes (resto)
    sobrenome = palavras[0]
    primeiros_nomes = palavras[1:]
    
    # Construir uma query que busca por nomes que contenham o sobrenome e os primeiros nomes
    query = {
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "nome": {
                                "query": sobrenome,
                                "boost": 2.0
                            }
                        }
                    }
                ],
                "should": []
            }
        }
    }
    
    # Adicionar condições para os primeiros nomes
    for nome in primeiros_nomes:
        query["query"]["bool"]["should"].append({
            "match": {
                "nome": nome
            }
        })
    
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
