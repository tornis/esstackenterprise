"""
Módulo para a regra hyphenate_names (hiphenização de nomes)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Adiciona um hífen entre duas palavras aleatórias do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com um hífen entre duas palavras
    """
    return hyphenate_random_words(texto)

def hyphenate_random_words(texto):
    """
    Adiciona um hífen entre duas palavras aleatórias do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com um hífen entre duas palavras
    """
    palavras = texto.split()
    if len(palavras) < 2:
        return texto
    
    idx = random.randint(0, len(palavras) - 2)
    palavras[idx] = palavras[idx] + '-' + palavras[idx+1]
    palavras.pop(idx+1)
    
    return ' '.join(palavras)


# Funções para busca de amostras

def construir_query_hyphenate_names(texto_base, max_samples=50, fuzziness="AUTO", operator="or"):
    """
    Constrói uma query específica para a regra hyphenate_names.
    Esta query busca nomes que contenham múltiplas palavras (espaços).
    
    Args:
        texto_base (str): O texto base para a busca
        max_samples (int): Número máximo de amostras a retornar
        fuzziness (str): Nível de fuzziness para a busca
        operator (str): Operador para a busca ("and" ou "or")
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para hyphenate_names, queremos nomes que contenham múltiplas palavras
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "nome": {
                                "query": texto_base,
                                "fuzziness": fuzziness,
                                "operator": operator
                            }
                        }
                    },
                    # Garantir que o nome contenha pelo menos um espaço
                    {
                        "regexp": {
                            "nome": ".*\\s+.*"  # Expressão regular para encontrar espaços
                        }
                    }
                ],
                "must_not": [
                    # Excluir nomes que já contenham hífen
                    {
                        "regexp": {
                            "nome": ".*-.*"  # Expressão regular para encontrar hífen
                        }
                    }
                ]
            }
        },
        "sort": [
            # Ordenar por quantidade de espaços (mais espaços primeiro)
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "doc['nome.keyword'].value.split(' ').length"
                    },
                    "order": "desc"
                }
            },
            "_score"
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'hyphenate_names': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def contar_palavras(texto):
    """
    Conta o número de palavras em um texto.
    
    Args:
        texto (str): O texto a ser analisado
        
    Returns:
        int: Número de palavras no texto
    """
    return len(texto.split())


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes adequados para a regra hyphenate_names.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'hyphenate_names'")
        
        # Construir a query específica para hyphenate_names
        query = construir_query_hyphenate_names(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome tem múltiplas palavras e não contém hífen
                if ' ' in nome and '-' not in nome:
                    # Contar o número de palavras
                    num_palavras = contar_palavras(nome)
                    
                    # Só considerar nomes com pelo menos 2 palavras
                    if num_palavras >= 2:
                        # Adicionar metadados adicionais
                        hit['_source']['num_palavras'] = num_palavras
                        hit['_source']['palavras'] = nome.split()
                        
                        # Adicionar à lista de nomes encontrados
                        nomes_encontrados.append(hit['_source'])
                        logger.info(f"Nome adequado para hiphenização encontrado: {nome} (palavras: {num_palavras})")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'hyphenate_names'")
        
        # Ordenar os resultados para priorizar nomes com mais palavras
        if nomes_encontrados:
            # Ordenar por número de palavras (mais palavras primeiro)
            nomes_encontrados.sort(key=lambda x: x.get('num_palavras', 0), reverse=True)
            logger.info(f"Nomes ordenados por número de palavras")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'hyphenate_names'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'hyphenate_names'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
