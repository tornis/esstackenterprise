"""
Módulo para a regra replace_consonant (substituir uma consoante aleatória por outra consoante)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

# Lista de consoantes
CONSOANTES = 'bcdfghjklmnpqrstvwxyz'
CONSOANTES_MAIUSCULAS = CONSOANTES.upper()

def aplicar_regra(texto):
    """
    Substitui uma consoante aleatória por outra consoante no texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com uma consoante substituída por outra consoante
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Encontrar todas as posições de consoantes no texto
    posicoes_consoantes = [i for i, char in enumerate(texto) if char.lower() in CONSOANTES]
    
    # Se não houver consoantes no texto, retornar o texto original
    if not posicoes_consoantes:
        return texto
    
    # Escolher uma posição aleatória para substituir
    posicao = random.choice(posicoes_consoantes)
    
    # Obter o caractere na posição escolhida
    char = texto[posicao]
    
    # Determinar se a letra é maiúscula ou minúscula
    if char.isupper():
        # Escolher uma consoante maiúscula aleatória diferente da original
        consoantes_disponiveis = CONSOANTES_MAIUSCULAS.replace(char, '')
        substituto = random.choice(consoantes_disponiveis)
    else:
        # Escolher uma consoante minúscula aleatória diferente da original
        consoantes_disponiveis = CONSOANTES.replace(char, '')
        substituto = random.choice(consoantes_disponiveis)
    
    # Substituir a consoante por outra consoante na posição escolhida
    texto_modificado = texto[:posicao] + substituto + texto[posicao+1:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_replace_consonant(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham consoantes para a regra replace_consonant.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para replace_consonant, queremos nomes que contenham consoantes
    # Como praticamente todos os nomes contêm consoantes, podemos usar uma query simples
    query = {
        "size": max_samples,
        "query": {
            "match_all": {}  # Buscar todos os nomes, pois quase todos terão consoantes
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'replace_consonant': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham consoantes para a regra replace_consonant.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes que contenham consoantes do índice {MAIN_INDEX_NAME} para a regra 'replace_consonant'")
        
        # Construir a query para replace_consonant
        query = construir_query_replace_consonant(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome contém consoantes
                posicoes_consoantes = [i for i, char in enumerate(nome) if char.lower() in CONSOANTES]
                if posicoes_consoantes:
                    # Adicionar metadados adicionais
                    hit['_source']['posicoes_consoantes'] = posicoes_consoantes
                    hit['_source']['quantidade_consoantes'] = len(posicoes_consoantes)
                    hit['_source']['consoantes'] = [nome[i] for i in posicoes_consoantes]
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para replace_consonant: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes que contêm consoantes para a regra 'replace_consonant'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'replace_consonant'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'replace_consonant'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
