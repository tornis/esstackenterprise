"""
Módulo para a regra replace_ch_cc_only_first (substituir as letras CH pelas letras CC, somente se estiverem na primeira posição do nome)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Substitui as letras CH pelas letras CC, somente se estiverem na primeira posição do nome.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com as letras CH substituídas por CC na primeira posição (se aplicável)
    """
    # Se o texto estiver vazio ou muito curto, retornar o texto original
    if not texto or len(texto) < 2:
        return texto
    
    # Verificar se os dois primeiros caracteres são "ch" (maiúscula, minúscula ou mista)
    if texto[:2].lower() != 'ch':
        return texto
    
    # Determinar se as letras são maiúsculas ou minúsculas
    if texto[0].isupper() and texto[1].isupper():
        substituto = 'CC'
    elif texto[0].isupper() and texto[1].islower():
        substituto = 'Cc'
    elif texto[0].islower() and texto[1].isupper():
        substituto = 'cC'
    else:
        substituto = 'cc'
    
    # Substituir as letras CH pelas letras CC na primeira posição
    texto_modificado = substituto + texto[2:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_replace_ch_cc_only_first(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que comecem com a sequência "ch" para a regra replace_ch_cc_only_first.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para replace_ch_cc_only_first, queremos nomes que comecem com a sequência "ch" (maiúscula ou minúscula)
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": [
                    {
                        "prefix": {
                            "nome": "ch"  # Nomes que começam com a sequência "ch" minúscula
                        }
                    },
                    {
                        "prefix": {
                            "nome": "CH"  # Nomes que começam com a sequência "CH" maiúscula
                        }
                    },
                    {
                        "prefix": {
                            "nome": "Ch"  # Nomes que começam com a sequência "Ch" mista
                        }
                    },
                    {
                        "prefix": {
                            "nome": "cH"  # Nomes que começam com a sequência "cH" mista
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'replace_ch_cc_only_first': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que comecem com a sequência "ch" para a regra replace_ch_cc_only_first.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes que comecem com a sequência 'ch' do índice {MAIN_INDEX_NAME} para a regra 'replace_ch_cc_only_first'")
        
        # Construir a query para replace_ch_cc_only_first
        query = construir_query_replace_ch_cc_only_first(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome começa com a sequência "ch" (maiúscula ou minúscula)
                if len(nome) >= 2 and nome[:2].lower() == 'ch':
                    # Adicionar metadados adicionais
                    hit['_source']['primeiros_caracteres'] = nome[:2]
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para replace_ch_cc_only_first: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes que começam com a sequência 'ch' para a regra 'replace_ch_cc_only_first'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'replace_ch_cc_only_first'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'replace_ch_cc_only_first'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
