"""
Módulo para a regra replace_char2num (substituir uma letra aleatória por um dígito numérico de aparência semelhante)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

# Mapeamento de letras para números de aparência semelhante
CHAR_TO_NUM_MAP = {
    'o': '0',
    'O': '0',
    'i': '1',
    'I': '1',
    'l': '1',
    'L': '1',
    'z': '2',
    'Z': '2',
    'e': '3',
    'E': '3',
    'a': '4',
    'A': '4',
    's': '5',
    'S': '5',
    'b': '6',
    'B': '6',
    'g': '9',
    'G': '9',
    'q': '9',
    'Q': '9'
}

def aplicar_regra(texto):
    """
    Substitui uma letra aleatória por um dígito numérico de aparência semelhante.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com uma letra substituída por um número semelhante
    """
    # Se o texto estiver vazio, retornar o texto original
    if not texto:
        return texto
    
    # Encontrar todas as posições de letras que podem ser substituídas por números semelhantes
    posicoes_substituiveis = [i for i, char in enumerate(texto) if char in CHAR_TO_NUM_MAP]
    
    # Se não houver letras substituíveis no texto, retornar o texto original
    if not posicoes_substituiveis:
        return texto
    
    # Escolher uma posição aleatória para substituir
    posicao = random.choice(posicoes_substituiveis)
    
    # Obter o caractere na posição escolhida
    char = texto[posicao]
    
    # Substituir a letra pelo número correspondente
    numero = CHAR_TO_NUM_MAP[char]
    
    # Substituir a letra pelo número na posição escolhida
    texto_modificado = texto[:posicao] + numero + texto[posicao+1:]
    
    return texto_modificado


# Funções para busca de amostras

def construir_query_replace_char2num(texto_base="", max_samples=50):
    """
    Constrói uma query para buscar nomes que contenham letras que podem ser substituídas por números semelhantes.
    
    Args:
        texto_base (str): O texto base para a busca (não utilizado nesta implementação)
        max_samples (int): Número máximo de amostras a retornar
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para replace_char2num, queremos nomes que contenham letras que podem ser substituídas por números semelhantes
    letras_substituiveis = list(CHAR_TO_NUM_MAP.keys())
    
    # Construir cláusulas should para cada letra substituível
    should_clauses = []
    for letra in letras_substituiveis:
        should_clauses.append({
            "wildcard": {
                "nome": f"*{letra}*"  # Nomes que contenham a letra
            }
        })
    
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "should": should_clauses,
                "minimum_should_match": 1
            }
        },
        "sort": [
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "Math.random()"  # Ordenação aleatória
                    },
                    "order": "asc"
                }
            }
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'replace_char2num': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que contenham letras que podem ser substituídas por números semelhantes.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca (não utilizado nesta implementação)
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes que contenham letras substituíveis por números do índice {MAIN_INDEX_NAME} para a regra 'replace_char2num'")
        
        # Construir a query para replace_char2num
        query = construir_query_replace_char2num(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                
                # Verificar se o nome contém letras que podem ser substituídas por números
                posicoes_substituiveis = [i for i, char in enumerate(nome) if char in CHAR_TO_NUM_MAP]
                if posicoes_substituiveis:
                    # Adicionar metadados adicionais
                    hit['_source']['posicoes_substituiveis'] = posicoes_substituiveis
                    hit['_source']['quantidade_substituiveis'] = len(posicoes_substituiveis)
                    hit['_source']['letras_substituiveis'] = [nome[i] for i in posicoes_substituiveis]
                    nomes_encontrados.append(hit['_source'])
                    logger.info(f"Nome adequado encontrado para replace_char2num: {nome}")
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes que contêm letras substituíveis por números para a regra 'replace_char2num'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'replace_char2num'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'replace_char2num'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
