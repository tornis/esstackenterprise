"""
Regra para substituir o primeiro nome por um alias ou abreviação.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Dicionário de aliases comuns para nomes em português
NOME_ALIASES = {
    "antonio": ["toni", "toninho", "tonio"],
    "carlos": ["carlinhos", "carlito", "cadu"],
    "eduardo": ["edu", "dudu", "duda"],
    "francisco": ["chico", "chicão", "fran"],
    "gabriel": ["gabi", "biel", "gabe"],
    "guilherme": ["gui", "guiga", "guigui"],
    "henrique": ["rick", "ricky", "rique"],
    "joão": ["jô", "jota", "jão"],
    "josé": ["zé", "zezé", "zeca"],
    "lucas": ["luquinhas", "luca", "luks"],
    "luiz": ["lu", "lula", "lui"],
    "marcelo": ["celo", "marcelo", "marcelinho"],
    "marcos": ["marquinhos", "marc", "marcão"],
    "matheus": ["mat", "teteu", "theus"],
    "paulo": ["paulinho", "pauli", "paulão"],
    "pedro": ["pedrinho", "pedrito", "peu"],
    "rafael": ["rafa", "rapha", "rafinha"],
    "ricardo": ["rick", "ricky", "cado"],
    "roberto": ["beto", "betinho", "robson"],
    "rodrigo": ["digo", "digão", "rô"],
    "thiago": ["thi", "thiaguinho", "gui"],
    "vitor": ["vitinho", "viti", "vito"],
    "alexandre": ["alex", "xande", "ale"],
    "anderson": ["andy", "andi", "son"],
    "andré": ["dé", "dedé", "deco"],
    "bruno": ["bru", "bruninho", "brubs"],
    "daniel": ["dan", "dani", "danny"],
    "fernando": ["fer", "nando", "fê"],
    "gustavo": ["guto", "gu", "guga"],
    "leonardo": ["léo", "lê", "leozinho"],
    "luis": ["lu", "lula", "lui"],
    "marcio": ["mah", "marcinho", "marci"],
    "mario": ["marinho", "mah", "mari"],
    "renato": ["rê", "nato", "renatinho"],
    "sergio": ["serjão", "sérgio", "serj"],
    "wagner": ["wag", "wagner", "ner"],
    "wellington": ["well", "tom", "ton"],
    "wilson": ["will", "wil", "son"],
    # Nomes femininos
    "adriana": ["dri", "adri", "ana"],
    "alessandra": ["ale", "lessa", "sandra"],
    "amanda": ["mandi", "mandy", "amandinha"],
    "ana": ["aninha", "nana", "anita"],
    "beatriz": ["bia", "bibi", "bea"],
    "bruna": ["bruninha", "bru", "brubs"],
    "camila": ["cami", "mila", "ca"],
    "carla": ["carlinha", "cacá", "caca"],
    "carolina": ["carol", "lina", "lol"],
    "claudia": ["clau", "cacau", "dinha"],
    "cristina": ["cris", "tina", "kika"],
    "daniela": ["dani", "dana", "ela"],
    "débora": ["deb", "debby", "deby"],
    "fernanda": ["fer", "nanda", "fê"],
    "gabriela": ["gabi", "gabe", "biela"],
    "isabela": ["isa", "bela", "isinha"],
    "jessica": ["jess", "jéssica", "jê"],
    "juliana": ["ju", "juju", "juli"],
    "larissa": ["lari", "lala", "issa"],
    "leticia": ["lê", "leti", "ticia"],
    "luciana": ["lu", "lulu", "luci"],
    "mariana": ["mari", "mary", "ma"],
    "natalia": ["nat", "nati", "talia"],
    "patricia": ["pati", "patty", "tricia"],
    "priscila": ["pri", "pris", "cila"],
    "rafaela": ["rafa", "rapha", "ela"],
    "renata": ["rê", "rena", "nata"],
    "roberta": ["beta", "berta", "robbie"],
    "sandra": ["sandrinha", "san", "sasa"],
    "simone": ["si", "sisi", "mone"],
    "tatiana": ["tati", "tata", "tiana"],
    "vanessa": ["van", "vane", "nessa"],
    "veronica": ["vero", "vera", "nica"]
}

def aplicar_regra(texto):
    """
    Substitui o primeiro nome por um alias ou abreviação.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com o primeiro nome substituído por um alias.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    palavras = texto.split()
    if not palavras:
        return texto
    
    # Pegar o primeiro nome
    primeiro_nome = palavras[0].lower()
    
    # Verificar se temos um alias para este nome
    if primeiro_nome in NOME_ALIASES:
        # Escolher um alias aleatório
        alias = random.choice(NOME_ALIASES[primeiro_nome])
        
        # Substituir o primeiro nome pelo alias
        palavras[0] = alias
    else:
        # Se não temos um alias específico, podemos tentar criar um
        if len(primeiro_nome) > 3:
            # Criar um diminutivo simples (primeiras 3 letras + "inho/inha")
            sufixo = "inho" if primeiro_nome[-1] not in "aeiou" else "inha"
            alias = primeiro_nome[:3] + sufixo
            palavras[0] = alias
    
    nome_modificado = " ".join(palavras)
    logger.info(f"Regra 'firstname_alias' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes que tenham primeiro nome
    com alias disponível, ideais para a regra 'firstname_alias'.
    """
    # Criar uma lista de nomes para os quais temos aliases
    nomes_com_alias = list(NOME_ALIASES.keys())
    
    # Criar condições para cada nome
    should_conditions = []
    for nome in nomes_com_alias:
        should_conditions.append({
            "match_phrase_prefix": {
                "nome": {
                    "query": nome,
                    "boost": 2.0
                }
            }
        })
    
    return {
        "query": {
            "bool": {
                "should": should_conditions,
                "minimum_should_match": 1
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
