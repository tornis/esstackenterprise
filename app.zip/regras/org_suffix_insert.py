"""
Regra para adicionar um sufixo comum a nomes de organizações.
"""
import random
import logging

# Configuração do logger
logger = logging.getLogger(__name__)

# Lista de sufixos comuns para organizações
ORG_SUFFIXES = [
    "Ltda.", "Ltd.", "S.A.", "S/A", "Inc.", "Corporation", "Corp.", "Limitada",
    "Eireli", "ME", "EPP", "Sociedade Anônima", "Companhia", "Cia.",
    "Group", "Grupo", "Holdings", "Empreendimentos", "Enterprises", "International",
    "Brasil", "Brazil", "Global", "Systems", "Sistemas", "Solutions", "Soluções",
    "Technology", "Tecnologia", "Industries", "Indústrias", "Services", "Serviços"
]

def contem_sufixo_org(texto):
    """
    Verifica se o texto já contém um sufixo de organização.
    
    Args:
        texto (str): O texto a ser verificado.
        
    Returns:
        bool: True se o texto já contém um sufixo de organização, False caso contrário.
    """
    for sufixo in ORG_SUFFIXES:
        if texto.endswith(sufixo) or f" {sufixo}" in texto:
            return True
    return False

def aplicar_regra(texto):
    """
    Adiciona um sufixo comum a um nome de organização.
    
    Args:
        texto (str): O nome a ser modificado.
        
    Returns:
        str: O nome com um sufixo de organização adicionado.
    """
    if not texto or not isinstance(texto, str):
        return ""
    
    # Se já contém um sufixo de organização, retorna o texto original
    if contem_sufixo_org(texto):
        return texto
    
    # Escolher um sufixo aleatório
    sufixo = random.choice(ORG_SUFFIXES)
    
    # Adicionar o sufixo ao nome
    nome_modificado = f"{texto} {sufixo}"
    
    logger.info(f"Regra 'org_suffix_insert' aplicada: '{texto}' -> '{nome_modificado}'")
    return nome_modificado

def construir_query_amostras():
    """
    Constrói uma query para buscar nomes de organizações que não contenham sufixos comuns,
    ideais para a regra 'org_suffix_insert'.
    """
    # Criar uma condição para cada sufixo
    must_not_conditions = []
    for sufixo in ORG_SUFFIXES:
        must_not_conditions.append({
            "wildcard": {
                "nome.keyword": f"*{sufixo}"
            }
        })
        must_not_conditions.append({
            "wildcard": {
                "nome.keyword": f"* {sufixo}"
            }
        })
    
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "exists": {
                            "field": "nome"
                        }
                    }
                ],
                "must_not": must_not_conditions,
                "should": [
                    # Preferência por nomes que pareçam ser de organizações
                    {"match": {"nome": "empresa"}},
                    {"match": {"nome": "companhia"}},
                    {"match": {"nome": "grupo"}},
                    {"match": {"nome": "indústria"}},
                    {"match": {"nome": "serviços"}},
                    {"match": {"nome": "tecnologia"}}
                ],
                "minimum_should_match": 0
            }
        }
    }

def buscar_nome_modificado(client, nome_modificado, index_name):
    """
    Busca o nome modificado no índice especificado.
    
    Args:
        client: Cliente OpenSearch.
        nome_modificado (str): O nome a ser buscado.
        index_name (str): O nome do índice.
        
    Returns:
        dict: O resultado da busca.
    """
    query = {
        "query": {
            "match_phrase": {
                "nome": nome_modificado
            }
        }
    }
    try:
        response = client.search(
            index=index_name,
            body=query
        )
        return response
    except Exception as e:
        logger.error(f"Erro ao buscar nome modificado '{nome_modificado}' no índice '{index_name}': {e}")
        return None
