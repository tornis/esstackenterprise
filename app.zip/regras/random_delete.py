"""
Módulo para a regra random_delete (remoção aleatória de caracteres)
"""
import random
import logging
import json
import re
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

# Constante para o nome do índice principal
MAIN_INDEX_NAME = "lista-tratada"

def aplicar_regra(texto):
    """
    Remove um caractere aleatório de cada palavra do texto.
    
    Args:
        texto (str): O texto a ser modificado
        
    Returns:
        str: O texto com um caractere removido de cada palavra
    """
    return ' '.join([remover_caractere_aleatorio(palavra) for palavra in texto.split()])

def remover_caractere_aleatorio(palavra):
    """
    Remove um caractere aleatório de uma palavra.
    
    Args:
        palavra (str): A palavra a ser modificada
        
    Returns:
        str: A palavra com um caractere removido
    """
    # Se a palavra for muito curta, retornar sem alteração
    if len(palavra) <= 1:
        return palavra
    
    # Escolher uma posição aleatória para remover
    posicao = random.randint(0, len(palavra) - 1)
    
    # Remover o caractere na posição escolhida
    return palavra[:posicao] + palavra[posicao+1:]

def remover_caractere_aleatorio_preservando_primeira(palavra):
    """
    Remove um caractere aleatório de uma palavra, preservando a primeira letra.
    
    Args:
        palavra (str): A palavra a ser modificada
        
    Returns:
        str: A palavra com um caractere removido, preservando a primeira letra
    """
    # Se a palavra for muito curta, retornar sem alteração
    if len(palavra) <= 2:  # Precisa ter pelo menos 3 caracteres (primeira letra + pelo menos 2 para escolher um)
        return palavra
    
    # Escolher uma posição aleatória para remover, começando da segunda letra (posição 1)
    posicao = random.randint(1, len(palavra) - 1)
    
    # Remover o caractere na posição escolhida, preservando a primeira letra
    return palavra[:posicao] + palavra[posicao+1:]


# Funções para busca de amostras

def construir_query_random_delete(texto_base, max_samples=50, fuzziness="AUTO", operator="or"):
    """
    Constrói uma query específica para a regra random_delete.
    Esta query busca nomes mais longos (com mais caracteres) que são mais adequados para demonstrar
    a regra de remoção aleatória de caracteres.
    
    Args:
        texto_base (str): O texto base para a busca
        max_samples (int): Número máximo de amostras a retornar
        fuzziness (str): Nível de fuzziness para a busca
        operator (str): Operador para a busca ("and" ou "or")
        
    Returns:
        dict: A query DSL para OpenSearch
    """
    # Para random_delete, queremos nomes com pelo menos 5 caracteres
    # para que a remoção de um caractere seja mais significativa
    query = {
        "size": max_samples,
        "query": {
            "bool": {
                "must": [
                    {
                        "match": {
                            "nome": {
                                "query": texto_base,
                                "fuzziness": fuzziness,
                                "operator": operator
                            }
                        }
                    }
                ],
                "filter": [
                    {
                        "script": {
                            "script": {
                                "source": "doc['nome.keyword'].value.length() >= 5"
                            }
                        }
                    }
                ]
            }
        },
        "sort": [
            # Ordenar por tamanho do nome (decrescente)
            {
                "_script": {
                    "type": "number",
                    "script": {
                        "source": "doc['nome.keyword'].value.length()"
                    },
                    "order": "desc"
                }
            },
            "_score"
        ]
    }
    
    logger.info(f"Query DSL construída para regra 'random_delete': {json.dumps(query, indent=2, ensure_ascii=False)}")
    return query


def executar_busca(client, query):
    """
    Executa uma busca no OpenSearch usando a query fornecida.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        query (dict): Query DSL para a busca
        
    Returns:
        list: Lista de resultados da busca
    """
    try:
        # Executar a busca no índice principal
        response = client.search(
            body=query,
            index=MAIN_INDEX_NAME
        )
        
        # Extrair os hits da resposta
        hits = response.get('hits', {}).get('hits', [])
        
        logger.info(f"Busca executada com sucesso. Encontrados {len(hits)} resultados.")
        return hits, query
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        return [], query


def buscar_amostras(client, texto_base, quantidade=50):
    """
    Busca amostras de nomes que são adequados para a regra random_delete.
    
    Args:
        client (OpenSearch): Cliente do OpenSearch
        texto_base (str): Texto base para a busca
        quantidade (int): Número de amostras a retornar
        
    Returns:
        tuple: (lista de nomes encontrados, informações da query)
    """
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra 'random_delete'")
        
        # Construir a query específica para random_delete
        query = construir_query_random_delete(texto_base, max_samples=quantidade)
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nome = hit['_source']['nome']
                # Adicionar metadados adicionais
                hit['_source']['tamanho_original'] = len(nome)
                nomes_encontrados.append(hit['_source'])
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra 'random_delete'")
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            logger.warning(f"Não foram encontrados nomes suficientes para a regra 'random_delete'. "
                          f"Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            if len(nomes_encontrados) == 0:
                logger.error(f"Nenhum nome adequado foi encontrado para a regra 'random_delete'. "
                            f"Verifique os critérios de busca.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        return [], query_info
