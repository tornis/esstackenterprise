# Gerador de Amostras por Regras Fonéticas/Grafêmicas

Este aplicativo Streamlit permite processar regras de variação textual para gerar consultas no OpenSearch e coletar amostras de documentos que correspondem a essas variações.

## Funcionalidades

- Leitura automática de regras do arquivo `rules.txt`
- Interface visual para seleção de regras por categoria
- Geração automática de variações fonéticas/grafêmicas (troca de letras, duplicação, etc.)
- Construção de queries DSL para OpenSearch
- Exibição dos resultados em tabela interativa
- Download dos resultados em formato CSV
- Indexação dos resultados em um índice de treinamento

## Requisitos

- Python 3.7+
- Streamlit
- OpenSearch
- python-dotenv
- pandas

## Configuração

1. Crie um arquivo `.env` na raiz do projeto com as seguintes variáveis:

```
# OpenSearch Connection Settings
OPENSEARCH_HOST=localhost
OPENSEARCH_PORT=9200
OPENSEARCH_USER=admin
OPENSEARCH_PASSWORD=sua_senha
OPENSEARCH_USE_SSL=true

# Certificate Paths (se necessário)
OPENSEARCH_CA_CERTS_PATH=./certs/ca.crt
OPENSEARCH_CLIENT_CERT_PATH=./certs/client.crt
OPENSEARCH_CLIENT_KEY_PATH=./certs/client.key

# Index Configuration
MAIN_INDEX_NAME=lista-tratada
```

2. Instale as dependências:

```
pip install -r requirements.txt
```

## Execução

Para iniciar o aplicativo, execute:

```
streamlit run app.py
```

## Uso

1. Selecione as regras desejadas no menu lateral
2. Configure o número de amostras por regra
3. Clique em "Executar Busca"
4. Visualize os resultados e faça o download dos arquivos CSV

## Estrutura do Projeto

- `app.py`: Aplicativo principal
- `rules.txt`: Arquivo com as regras de variação textual
- `.env`: Configurações de conexão com o OpenSearch
- `requirements.txt`: Dependências do projeto
