import os
import re
import csv
import json
import random
import logging
import pandas as pd
import streamlit as st
from datetime import datetime
from dotenv import load_dotenv
from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth
from opensearchpy.helpers import bulk
import logging
import base64
from typing import List, Dict, Any, Tuple

# Importar funções auxiliares diretamente dos módulos de regras
from regras.remove_special_char import contem_caracteres_especiais, extrair_caracteres_especiais
from regras.replace_dbl2sgl import contem_letras_duplicadas, extrair_letras_duplicadas

# Importar módulos de regras específicas para busca de amostras
from regras.random_delete import buscar_amostras as buscar_amostras_random_delete
from regras.random_delete_not_first import buscar_amostras as buscar_amostras_random_delete_not_first
from regras.replace_dbl2sgl import buscar_amostras as buscar_amostras_replace_dbl2sgl
from regras.add_parentheses import buscar_amostras as buscar_amostras_add_parentheses
from regras.add_special_char import buscar_amostras as buscar_amostras_add_special_char
from regras.add_trailing_a import buscar_amostras as buscar_amostras_add_trailing_a
from regras.add_trailing_e import buscar_amostras as buscar_amostras_add_trailing_e
from regras.add_trailing_s import buscar_amostras as buscar_amostras_add_trailing_s
from regras.insert_3dots_first import buscar_amostras as buscar_amostras_insert_3dots_first
from regras.insert_apostrophe import buscar_amostras as buscar_amostras_insert_apostrophe
from regras.insert_slash_first import buscar_amostras as buscar_amostras_insert_slash_first
from regras.random_insert import buscar_amostras as buscar_amostras_random_insert
from regras.random_insert_not_first import buscar_amostras as buscar_amostras_random_insert_not_first
from regras.random_insert_only_first import buscar_amostras as buscar_amostras_random_insert_only_first
from regras.replace_sgl2dbl import buscar_amostras as buscar_amostras_replace_sgl2dbl
from regras.move_apostrophe import buscar_amostras as buscar_amostras_move_apostrophe
from regras.move_colon import buscar_amostras as buscar_amostras_move_colon
from regras.move_comma import buscar_amostras as buscar_amostras_move_comma
from regras.move_dash import buscar_amostras as buscar_amostras_move_dash
from regras.move_parentheses import buscar_amostras as buscar_amostras_move_parentheses
from regras.move_special_char import buscar_amostras as buscar_amostras_move_special_char
from regras.replace_1st_char import buscar_amostras as buscar_amostras_replace_1st_char
from regras.replace_I_l import buscar_amostras as buscar_amostras_replace_I_l
from regras.replace_c_k import buscar_amostras as buscar_amostras_replace_c_k
from regras.replace_c_k_not_first import buscar_amostras as buscar_amostras_replace_c_k_not_first
from regras.replace_c_k_only_first import buscar_amostras as buscar_amostras_replace_c_k_only_first
from regras.replace_c_s import buscar_amostras as buscar_amostras_replace_c_s
from regras.replace_c_s_not_first import buscar_amostras as buscar_amostras_replace_c_s_not_first
from regras.replace_c_s_only_first import buscar_amostras as buscar_amostras_replace_c_s_only_first
from regras.replace_ch_cc import buscar_amostras as buscar_amostras_replace_ch_cc
from regras.replace_ch_cc_not_first import buscar_amostras as buscar_amostras_replace_ch_cc_not_first
from regras.replace_ch_cc_only_first import buscar_amostras as buscar_amostras_replace_ch_cc_only_first
from regras.replace_char2num import buscar_amostras as buscar_amostras_replace_char2num
from regras.replace_consonant import buscar_amostras as buscar_amostras_replace_consonant
from regras.replace_consonant_not_first import buscar_amostras as buscar_amostras_replace_consonant_not_first
from regras.replace_g_j import buscar_amostras as buscar_amostras_replace_g_j
from regras.replace_g_j_not_first import buscar_amostras as buscar_amostras_replace_g_j_not_first
from regras.replace_g_j_only_first import buscar_amostras as buscar_amostras_replace_g_j_only_first
from regras.adjacent_transpose import buscar_amostras as buscar_amostras_adjacent_transpose
from regras.adjacent_transpose_first import buscar_amostras as buscar_amostras_adjacent_transpose_first
from regras.adjacent_transpose_last import buscar_amostras as buscar_amostras_adjacent_transpose_last
from regras.transpose_cmn_dbl import buscar_amostras as buscar_amostras_transpose_cmn_dbl
from regras.clear_firstname import buscar_amostras as buscar_amostras_clear_firstname
from regras.org_suffix_delete import buscar_amostras as buscar_amostras_org_suffix_delete
from regras.random_delete_word import buscar_amostras as buscar_amostras_random_delete_word
from regras.remove_stop_word import buscar_amostras as buscar_amostras_remove_stop_word

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Carregar variáveis de ambiente
load_dotenv()

# Configurações do OpenSearch
OPENSEARCH_HOST = os.getenv("OPENSEARCH_HOST", "localhost")
OPENSEARCH_PORT = int(os.getenv("OPENSEARCH_PORT", "9200"))
OPENSEARCH_USER = os.getenv("OPENSEARCH_USER", "admin")
OPENSEARCH_PASSWORD = os.getenv("OPENSEARCH_PASSWORD", "")
OPENSEARCH_USE_SSL = os.getenv("OPENSEARCH_USE_SSL", "true").lower() == "true"
OPENSEARCH_VERIFY_CERTS = os.getenv("OPENSEARCH_VERIFY_CERTS", "false").lower() == "true"
OPENSEARCH_SSL_SHOW_WARN = os.getenv("OPENSEARCH_SSL_SHOW_WARN", "false").lower() == "true"
OPENSEARCH_CA_CERTS_PATH = os.getenv("OPENSEARCH_CA_CERTS_PATH", "./certs/ca.crt")
OPENSEARCH_CLIENT_CERT_PATH = os.getenv("OPENSEARCH_CLIENT_CERT_PATH", "./certs/client.crt")
OPENSEARCH_CLIENT_KEY_PATH = os.getenv("OPENSEARCH_CLIENT_KEY_PATH", "./certs/client.key")

# Índices
MAIN_INDEX_NAME = os.getenv("MAIN_INDEX_NAME", "lista-tratada")
TRAIN_INDEX_NAME = os.getenv("TRAIN_INDEX_NAME", "listra-tratada-train")  # Índice para indexar os resultados

# Função para conectar ao OpenSearch
def get_opensearch_client():
    try:
        # Configurações de autenticação e SSL
        auth = (OPENSEARCH_USER, OPENSEARCH_PASSWORD)
        ssl_context = None
        
        if OPENSEARCH_USE_SSL:
            import ssl
            
            # Se não for verificar certificados, não tenta carregar os arquivos de certificado
            if OPENSEARCH_VERIFY_CERTS:
                ssl_context = ssl.create_default_context(cafile=OPENSEARCH_CA_CERTS_PATH)
                if os.path.exists(OPENSEARCH_CLIENT_CERT_PATH) and os.path.exists(OPENSEARCH_CLIENT_KEY_PATH):
                    ssl_context.load_cert_chain(
                        certfile=OPENSEARCH_CLIENT_CERT_PATH,
                        keyfile=OPENSEARCH_CLIENT_KEY_PATH
                    )
            else:
                # Criar um contexto SSL que ignora verificações de certificado
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
        
        # Criar cliente OpenSearch
        client = OpenSearch(
            hosts=[{'host': OPENSEARCH_HOST, 'port': OPENSEARCH_PORT}],
            http_auth=auth,
            use_ssl=OPENSEARCH_USE_SSL,
            verify_certs=OPENSEARCH_VERIFY_CERTS,  # Usar configuração do .env
            ssl_show_warn=OPENSEARCH_SSL_SHOW_WARN,  # Usar configuração do .env
            ssl_context=ssl_context,
            connection_class=RequestsHttpConnection
        )
        
        # Verificar a conexão
        info = client.info()
        logger.info(f"Conectado ao OpenSearch: {info['version']['number']}")
        return client
    except Exception as e:
        logger.error(f"Erro ao conectar ao OpenSearch: {str(e)}")
        st.error(f"Erro ao conectar ao OpenSearch: {str(e)}")
        return None

# Função para ler as regras do arquivo
def ler_regras(arquivo="rules.txt"):
    try:
        regras = []
        with open(arquivo, 'r', encoding='utf-8') as f:
            linhas = f.readlines()
            
        categoria_atual = None
        for linha in linhas:
            linha = linha.strip()
            if not linha:
                continue
                
            # Verificar se é uma categoria
            if linha.startswith('##'):
                categoria_atual = linha.replace('##', '').strip()
                continue
                
            # Verificar se é uma regra
            if linha.startswith('-'):
                nome_regra = re.search(r'\*\*(.*?)\*\*', linha)
                if nome_regra:
                    nome_regra = nome_regra.group(1).strip()
                    descricao = linha.split(':', 1)[-1].strip() if ':' in linha else linha.split('**', 2)[-1].strip()
                    regras.append({
                        'categoria': categoria_atual,
                        'nome': nome_regra,
                        'descricao': descricao
                    })
        
        return regras
    except Exception as e:
        logger.error(f"Erro ao ler regras: {str(e)}")
        st.error(f"Erro ao ler regras: {str(e)}")
        return []

# Função para gerar variações fonéticas/grafêmicas com base na regra
def gerar_variacoes(texto, regra):
    # Verificar se a regra é um dicionário e extrair o nome
    nome_regra = regra
    if isinstance(regra, dict):
        nome_regra = regra.get('nome', '')
    
    # Verificar se o nome da regra é válido
    if not nome_regra:
        logger.warning("Nome da regra inválido ou vazio. Retornando texto original.")
        return texto
    
    # Importar dinamicamente o módulo da regra e usar sua função aplicar_regra
    try:
        # Tentar importar o módulo da regra
        modulo = __import__(f"regras.{nome_regra}", fromlist=["aplicar_regra"])
        
        # Verificar se o módulo tem a função aplicar_regra
        if hasattr(modulo, "aplicar_regra"):
            # Chamar a função aplicar_regra do módulo
            return modulo.aplicar_regra(texto)
        else:
            logger.warning(f"Módulo '{nome_regra}' não tem a função aplicar_regra. Retornando texto original.")
            return texto
    except ImportError:
        logger.warning(f"Não foi possível importar o módulo '{nome_regra}'. Retornando texto original.")
        return texto

# Nota: As funções auxiliares para as variações foram movidas para os módulos em regras/

# Função para buscar nomes reais do índice lista-tratada com base na regra
def buscar_nomes_do_indice(client, regra, quantidade=50):
    try:
        logger.info(f"Buscando {quantidade} nomes do índice {MAIN_INDEX_NAME} para a regra '{regra['nome']}'")
        
        # Verificar qual regra está sendo usada para delegar para o módulo específico
        nome_regra = regra.get('nome', '').lower()
        
        # Delegar para módulos específicos que implementam busca de amostras
        if nome_regra == 'random_delete':
            # Usar a busca especializada do módulo random_delete
            from regras.random_delete import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'random_delete_not_first':
            # Usar a busca especializada do módulo random_delete_not_first
            from regras.random_delete_not_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'remove_special_char':
            # Usar a busca especializada do módulo remove_special_char
            from regras.remove_special_char import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_dbl2sgl':
            # Usar a busca especializada do módulo replace_dbl2sgl
            from regras.replace_dbl2sgl import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_sgl2dbl':
            # Usar a busca especializada do módulo replace_sgl2dbl
            from regras.replace_sgl2dbl import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'adjacent_transpose':
            # Usar a busca especializada do módulo adjacent_transpose
            from regras.adjacent_transpose import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'hyphenate_names':
            # Usar a busca especializada do módulo hyphenate_names
            from regras.hyphenate_names import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'add_parentheses':
            # Usar a busca especializada do módulo add_parentheses
            from regras.add_parentheses import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'add_special_char':
            # Usar a busca especializada do módulo add_special_char
            from regras.add_special_char import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'add_trailing_a':
            # Usar a busca especializada do módulo add_trailing_a
            from regras.add_trailing_a import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'add_trailing_e':
            # Usar a busca especializada do módulo add_trailing_e
            from regras.add_trailing_e import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'add_trailing_s':
            # Usar a busca especializada do módulo add_trailing_s
            from regras.add_trailing_s import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'insert_3dots_first':
            # Usar a busca especializada do módulo insert_3dots_first
            from regras.insert_3dots_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'insert_apostrophe':
            # Usar a busca especializada do módulo insert_apostrophe
            from regras.insert_apostrophe import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'insert_slash_first':
            # Usar a busca especializada do módulo insert_slash_first
            from regras.insert_slash_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'random_insert':
            # Usar a busca especializada do módulo random_insert
            from regras.random_insert import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'random_insert_not_first':
            # Usar a busca especializada do módulo random_insert_not_first
            from regras.random_insert_not_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'random_insert_only_first':
            # Usar a busca especializada do módulo random_insert_only_first
            from regras.random_insert_only_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'move_apostrophe':
            # Usar a busca especializada do módulo move_apostrophe
            from regras.move_apostrophe import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'move_colon':
            # Usar a busca especializada do módulo move_colon
            from regras.move_colon import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'move_comma':
            # Usar a busca especializada do módulo move_comma
            from regras.move_comma import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'move_dash':
            # Usar a busca especializada do módulo move_dash
            from regras.move_dash import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'move_parentheses':
            # Usar a busca especializada do módulo move_parentheses
            from regras.move_parentheses import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'move_special_char':
            # Usar a busca especializada do módulo move_special_char
            from regras.move_special_char import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_1st_char':
            # Usar a busca especializada do módulo replace_1st_char
            from regras.replace_1st_char import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_i_l':
            # Usar a busca especializada do módulo replace_I_l
            from regras.replace_I_l import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_c_k':
            # Usar a busca especializada do módulo replace_c_k
            from regras.replace_c_k import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_c_k_not_first':
            # Usar a busca especializada do módulo replace_c_k_not_first
            from regras.replace_c_k_not_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_c_k_only_first':
            # Usar a busca especializada do módulo replace_c_k_only_first
            from regras.replace_c_k_only_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_c_s':
            # Usar a busca especializada do módulo replace_c_s
            from regras.replace_c_s import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_c_s_not_first':
            # Usar a busca especializada do módulo replace_c_s_not_first
            from regras.replace_c_s_not_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_c_s_only_first':
            # Usar a busca especializada do módulo replace_c_s_only_first
            from regras.replace_c_s_only_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_ch_cc':
            # Usar a busca especializada do módulo replace_ch_cc
            from regras.replace_ch_cc import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_ch_cc_not_first':
            # Usar a busca especializada do módulo replace_ch_cc_not_first
            from regras.replace_ch_cc_not_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_ch_cc_only_first':
            # Usar a busca especializada do módulo replace_ch_cc_only_first
            from regras.replace_ch_cc_only_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_char2num':
            # Usar a busca especializada do módulo replace_char2num
            from regras.replace_char2num import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_consonant':
            # Usar a busca especializada do módulo replace_consonant
            from regras.replace_consonant import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_consonant_not_first':
            # Usar a busca especializada do módulo replace_consonant_not_first
            from regras.replace_consonant_not_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_g_j':
            # Usar a busca especializada do módulo replace_g_j
            from regras.replace_g_j import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_g_j_not_first':
            # Usar a busca especializada do módulo replace_g_j_not_first
            from regras.replace_g_j_not_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'replace_g_j_only_first':
            # Usar a busca especializada do módulo replace_g_j_only_first
            from regras.replace_g_j_only_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'adjacent_transpose':
            # Usar a busca especializada do módulo adjacent_transpose
            from regras.adjacent_transpose import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'adjacent_transpose_first':
            # Usar a busca especializada do módulo adjacent_transpose_first
            from regras.adjacent_transpose_first import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'adjacent_transpose_last':
            # Usar a busca especializada do módulo adjacent_transpose_last
            from regras.adjacent_transpose_last import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'transpose_cmn_dbl':
            # Usar a busca especializada do módulo transpose_cmn_dbl
            from regras.transpose_cmn_dbl import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'clear_firstname':
            # Usar a busca especializada do módulo clear_firstname
            from regras.clear_firstname import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'org_suffix_delete':
            # Usar a busca especializada do módulo org_suffix_delete
            from regras.org_suffix_delete import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'random_delete_word':
            # Usar a busca especializada do módulo random_delete_word
            from regras.random_delete_word import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
            
        elif nome_regra == 'remove_stop_word':
            # Usar a busca especializada do módulo remove_stop_word
            from regras.remove_stop_word import buscar_amostras
            return buscar_amostras(client, "nome", quantidade)
        
        # Para regras que ainda não têm módulo de busca específico, usar a estratégia padrão
        # Construir uma query para buscar nomes relevantes para a regra
        categoria = regra.get('categoria', '').lower()
        
        # Definir termos de busca com base na categoria e nome da regra
        termos_busca = []
        
        # Adicionar termos de busca baseados na categoria
        if 'character replacement' in categoria:
            # Para regras de substituição de caracteres, buscar nomes que contenham os caracteres relevantes
            if 'g_j' in nome_regra:
                termos_busca.extend(['g', 'j'])
            elif 's_z' in nome_regra:
                termos_busca.extend(['s', 'z'])
            elif 'c_s' in nome_regra or 's_c' in nome_regra:
                termos_busca.extend(['c', 's'])
            elif 'c_k' in nome_regra or 'k_c' in nome_regra:
                termos_busca.extend(['c', 'k'])
            elif 'i_y' in nome_regra or 'y_i' in nome_regra:
                termos_busca.extend(['i', 'y'])
        elif 'character duplication' in categoria:
            # Para regras de duplicação de caracteres, buscar nomes com letras duplicadas ou sem duplicação
            if 'sgl2dbl' in nome_regra:  # Single to double
                termos_busca.extend(['a', 'e', 'i', 'o', 'u', 'r', 's', 'l', 'n'])
            elif 'dbl2sgl' in nome_regra:  # Double to single
                # Buscar nomes com letras duplicadas como 'll', 'zz', 'tt', 'rr', 'ss', 'nn', 'mm'
                termos_busca.extend(['ll', 'zz', 'tt', 'rr', 'ss', 'nn', 'mm', 'cc', 'dd', 'ff', 'gg', 'pp', 'bb'])
        elif 'case modification' in categoria:
            # Para regras de modificação de maiúsculas/minúsculas, buscar nomes com variações de caso
            termos_busca.extend(['A', 'E', 'I', 'O', 'U', 'a', 'e', 'i', 'o', 'u'])
        elif 'whitespace modification' in categoria:
            # Para regras de modificação de espaços, buscar nomes compostos
            termos_busca.extend([' '])
        elif 'character removal' in categoria:
            # Para regras de remoção de caracteres, buscar nomes mais longos
            if 'remove_special_char' in nome_regra:
                # Para a regra de remoção de caracteres especiais, buscar nomes que contenham caracteres especiais
                termos_busca.extend(['-', '.', ',', '&', "'", '"', '!', '?', '(', ')', '[', ']', '{', '}', '@', '#', '$', '%', '^', '*', '+', '=', ':', ';'])
            else:
                termos_busca.extend(['a', 'e', 'i', 'o', 'u', 'r', 's', 'l', 'n'])
        
        # Se não houver termos específicos, usar termos genéricos
        if not termos_busca:
            termos_busca = ['a', 'e', 'i', 'o', 'u']
        
        # Construir queries para cada termo
        should_clauses = []
        
        # Verificar o tipo de regra para usar a estratégia de busca adequada
        if 'remove_special_char' in nome_regra:
            # Para caracteres especiais, usar regex para encontrar nomes que contenham qualquer caractere especial
            should_clauses.append({
                "regexp": {
                    "nome": ".*[^\\w\\s].*"  # Expressão regular para encontrar qualquer caractere que não seja letra, número ou espaço
                }
            })
            
            # Adicionar também buscas específicas para caracteres especiais comuns
            for termo in termos_busca:
                should_clauses.append({"wildcard": {"nome": f"*{termo}*"}})
                
        elif 'dbl2sgl' in nome_regra:
            # Para a regra replace_dbl2sgl, usar a query fornecida pelo usuário
            # Substituindo a construção dinâmica de should_clauses pela query específica
            query = {
                "size": quantidade,
                "query": {
                    "bool": {
                        "should": [
                            {"wildcard": {"nome": "*ll*"}},
                            {"wildcard": {"nome": "*nn*"}},
                            {"wildcard": {"nome": "*ss*"}},
                            {"wildcard": {"nome": "*mm*"}},
                            {"wildcard": {"nome": "*zz*"}},
                            {"wildcard": {"nome": "*cc*"}},
                            {"wildcard": {"nome": "*ff*"}},
                            {"wildcard": {"nome": "*rr*"}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "sort": [{"_script": {
                    "script": "Math.random()",
                    "type": "number",
                    "order": "asc"
                }}]
            }
            
            # Formatar a query para exibição
            query_formatada = json.dumps(query, indent=2, ensure_ascii=False)
            logger.info(f"Query de busca de amostras para replace_dbl2sgl: {query_formatada}")
            
            # Executar a busca
            resultados, info_busca = executar_busca(client, query)
            
            # Processar os resultados
            nomes_encontrados = []
            for hit in resultados:
                if '_source' in hit and 'nome' in hit['_source']:
                    doc = hit['_source']
                    
                    # Verificar se o nome tem letras duplicadas e adicionar essa informação ao documento
                    nome = doc.get('nome', '')
                    letras_duplicadas = extrair_letras_duplicadas(nome)
                    doc['letras_duplicadas'] = letras_duplicadas
                    
                    nomes_encontrados.append(doc)
            
            # Adicionar a query utilizada aos metadados para exibição
        query = {
            "size": quantidade,
            "query": {
                "match_all": {}
            },
            "sort": [{"_script": {
                "script": "Math.random()",
                "type": "number",
                "order": "asc"
            }}]
        }
        
        # Formatar a query para exibição
        query_formatada = json.dumps(query, indent=2, ensure_ascii=False)
        logger.info(f"Query genérica de busca de amostras: {query_formatada}")
        
        # Executar a busca
        resultados, info_busca = executar_busca(client, query)
        
        # Extrair os nomes dos resultados
        nomes_encontrados = []
        for hit in resultados:
            if '_source' in hit and 'nome' in hit['_source']:
                nomes_encontrados.append(hit['_source'])
        
        logger.info(f"Encontrados {len(nomes_encontrados)} nomes para a regra '{regra['nome']}'")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': query_formatada
        }
        
        # Verificar se encontrou nomes suficientes
        if len(nomes_encontrados) < quantidade:
            # Para todas as regras, não usar busca genérica
            logger.warning(f"Não foram encontrados nomes suficientes para a regra '{regra['nome']}'. Retornando apenas os {len(nomes_encontrados)} nomes encontrados.")
            
            # Mensagens específicas para regras especiais
            if 'remove_special_char' in regra.get('nome', '').lower():
                if len(nomes_encontrados) == 0:
                    logger.error(f"Nenhum nome com caracteres especiais foi encontrado para a regra '{regra['nome']}'. Verifique se existem nomes com caracteres especiais no índice.")
                else:
                    logger.info(f"Encontrados {len(nomes_encontrados)} nomes com caracteres especiais para a regra '{regra['nome']}'.")
            elif 'dbl2sgl' in regra.get('nome', '').lower():
                if len(nomes_encontrados) == 0:
                    logger.error(f"Nenhum nome com letras duplicadas foi encontrado para a regra '{regra['nome']}'. Verifique se existem nomes com letras duplicadas no índice.")
                else:
                    logger.info(f"Encontrados {len(nomes_encontrados)} nomes com letras duplicadas para a regra '{regra['nome']}'.")
            else:
                if len(nomes_encontrados) == 0:
                    logger.error(f"Nenhum nome relevante foi encontrado para a regra '{regra['nome']}'. Verifique os critérios de busca.")
                else:
                    logger.info(f"Encontrados apenas {len(nomes_encontrados)} nomes relevantes para a regra '{regra['nome']}'.")
        
        # Adicionar a query utilizada aos metadados para exibição
        query_info = {
            'query_json': query,
            'query_formatada': json.dumps(query, indent=2, ensure_ascii=False)
        }
        
        # Retornar os nomes encontrados e a query utilizada
        return nomes_encontrados, query_info
    except Exception as e:
        logger.error(f"Erro ao buscar nomes do índice: {str(e)}")
        # Em caso de erro, não fazer busca genérica, apenas retornar lista vazia e informações do erro
        query_info = {
            'query_json': {},
            'query_formatada': 'Erro na busca: ' + str(e),
            'erro': str(e)
        }
        
        # Se todas as tentativas falharem, retornar uma lista vazia
        logger.error("Não foi possível recuperar nomes do índice")
        return [], query_info

# Esta função foi removida pois agora usamos apenas nomes reais do índice lista-tratada
# Caso não haja nomes suficientes com os critérios específicos, usamos uma busca genérica no índice

# Função para construir a query DSL do OpenSearch
def construir_query_dsl(texto_base, regra, max_samples=50, usar_variacoes=True, fuzziness="AUTO", operator="or", minimum_should_match=1):
    if usar_variacoes:
        # Gerar múltiplas variações do texto base
        variacoes = []
        # Adicionar o texto base original
        variacoes.append(texto_base)
        
        # Gerar 3 variações diferentes usando a regra
        for _ in range(3):
            variacao = gerar_variacoes(texto_base, regra)
            if variacao != texto_base and variacao not in variacoes:
                variacoes.append(variacao)
        
        # Construir a query usando o operador should (OR lógico)
        should_clauses = []
        for variacao in variacoes:
            # Adicionar match com fuzziness e operator
            should_clauses.append({
                "match": {
                    "nome": {
                        "query": variacao,
                        "fuzziness": fuzziness,
                        "operator": operator
                    }
                }
            })
            
            # Adicionar variações com wildcards para ampliar o escopo
            if len(variacao) > 3:
                should_clauses.append({"wildcard": {"nome": f"*{variacao[1:-1]}*"}})
        
        # Converter minimum_should_match para inteiro ou string conforme necessário
        msm_value = minimum_should_match
        if isinstance(minimum_should_match, str) and minimum_should_match.isdigit():
            msm_value = int(minimum_should_match)
        
        query = {
            "size": max_samples,
            "query": {
                "bool": {
                    "should": should_clauses,
                    "minimum_should_match": msm_value
                }
            }
        }
    else:
        # Query simples para buscar apenas o texto base com fuzziness e operator
        query = {
            "size": max_samples,
            "query": {
                "match": {
                    "nome": {
                        "query": texto_base,
                        "fuzziness": fuzziness,
                        "operator": operator
                    }
                }
            }
        }
    
    # Log da query para debug
    logger.info(f"Query DSL construída para regra '{regra['nome']}': {json.dumps(query, indent=2, ensure_ascii=False)}")
    logger.info(f"Parâmetros de busca: fuzziness={fuzziness}, operator={operator}, minimum_should_match={minimum_should_match}")
    
    return query

# Função para executar a busca no OpenSearch
def executar_busca(client, query, index_name=MAIN_INDEX_NAME):
    try:
        resultados = client.search(
            body=query,
            index=index_name
        )
        
        # Extrair os hits completos dos resultados
        hits = resultados.get('hits', {}).get('hits', [])
        
        # Adicionar informações sobre a busca
        info_busca = {
            'total_hits': resultados.get('hits', {}).get('total', {}).get('value', 0),
            'max_score': resultados.get('hits', {}).get('max_score', 0),
            'took_ms': resultados.get('took', 0)
        }
        
        # Retornar os hits completos, não apenas os _source
        return hits, info_busca
    except Exception as e:
        logger.error(f"Erro ao executar busca: {str(e)}")
        st.error(f"Erro ao executar busca: {str(e)}")
        return [], {}

# Função para indexar os resultados no índice de treinamento
def indexar_resultados(client, documentos, regra, index_name=TRAIN_INDEX_NAME):
    try:
        # Verificar se o índice existe, caso contrário, criar
        if not client.indices.exists(index=index_name):
            client.indices.create(
                index=index_name,
                body={
                    "mappings": {
                        "properties": {
                            "nome": {"type": "text"},
                            "nome_modificado": {"type": "text"},
                            "categoria": {"type": "keyword"},
                            "regra_aplicada": {"type": "keyword"},
                            "data_indexacao": {"type": "date"}
                        }
                    }
                }
            )
            logger.info(f"Índice {index_name} criado com sucesso")
        
        # Preparar documentos para indexação
        acoes = []
        for doc in documentos:
            doc_indexar = doc.copy()
            doc_indexar['categoria'] = regra.get('categoria', 'Não categorizado')
            doc_indexar['regra_aplicada'] = regra.get('nome', '')
            doc_indexar['data_indexacao'] = pd.Timestamp.now().isoformat()
            
            # Gerar a variação do nome conforme a regra
            nome_original = doc.get('nome', '')
            nome_modificado = gerar_variacoes(nome_original, regra)
            doc_indexar['nome_modificado'] = nome_modificado
            
            acoes.append({
                "_index": index_name,
                "_source": doc_indexar
            })
        
        # Indexar documentos em massa
        if acoes:
            resultado = bulk(client, acoes)
            logger.info(f"Indexados {len(acoes)} documentos para a regra '{regra.get('nome', '')}' da categoria '{regra.get('categoria', '')}")
            st.success(f"Indexados {len(acoes)} documentos no índice '{index_name}' para a regra '{regra.get('nome', '')}' da categoria '{regra.get('categoria', '')}")
            return True, acoes
        
        return False, []
    except Exception as e:
        logger.error(f"Erro ao indexar resultados: {str(e)}")
        st.error(f"Erro ao indexar resultados: {str(e)}")
        return False, []

# Função para converter os resultados para CSV e gerar link de download
def gerar_csv_download(documentos, nome_regra):
    try:
        # Converter para DataFrame
        df = pd.DataFrame(documentos)
        
        # Gerar CSV
        csv = df.to_csv(index=False)
        
        # Codificar em base64 para download
        b64 = base64.b64encode(csv.encode()).decode()
        href = f'<a href="data:file/csv;base64,{b64}" download="amostras_{nome_regra}.csv" class="btn" style="background-color:#4CAF50;color:white;padding:8px 12px;text-decoration:none;border-radius:4px;cursor:pointer;">Download CSV - {len(documentos)} registros</a>'
        
        # Salvar também localmente
        try:
            df.to_csv(f"amostras_{nome_regra}.csv", index=False, encoding='utf-8')
            logger.info(f"Arquivo CSV salvo localmente: amostras_{nome_regra}.csv")
        except Exception as e_local:
            logger.warning(f"Não foi possível salvar o arquivo localmente: {str(e_local)}")
        
        return href
    except Exception as e:
        logger.error(f"Erro ao gerar CSV: {str(e)}")
        st.error(f"Erro ao gerar CSV: {str(e)}")
        return ""

# Interface Streamlit
def main():
    st.set_page_config(page_title="Gerador de Amostras por Regras", layout="wide")
    st.title("Gerador de Amostras por Regras Fonéticas/Grafêmicas")
    st.subheader("Processamento de regras de variação textual para OpenSearch")
    
    # Exibir informações sobre o aplicativo
    with st.expander("Sobre este aplicativo"):
        st.markdown("""
        Este aplicativo permite processar regras de variação textual para gerar consultas no OpenSearch. 
        Para cada regra selecionada, o sistema:
        
        1. Seleciona 50 nomes e armazena no índice "lista-tratada-train" com a categoria e nome da regra
        2. Modifica cada nome conforme a regra selecionada
        3. Consulta o índice "lista-tratada" com o nome modificado
        4. Apresenta o nome original, a modificação e o resultado da busca
        
        Selecione as regras desejadas no menu lateral e clique em "Executar Busca".
        """)
        
    # Exibir configurações atuais
    with st.expander("Configurações atuais"):
        st.markdown(f"""
        **OpenSearch**:
        - Host: `{OPENSEARCH_HOST}`
        - Port: `{OPENSEARCH_PORT}`
        - Índice principal: `{MAIN_INDEX_NAME}`
        - Índice de treinamento: `{TRAIN_INDEX_NAME}`
        - SSL habilitado: `{OPENSEARCH_USE_SSL}`
        - Verificar certificados: `{OPENSEARCH_VERIFY_CERTS}`
        """)
    
    # Carregar regras
    regras = ler_regras()
    
    if not regras:
        st.error("Não foi possível carregar as regras do arquivo rules.txt")
        return
    
    # Agrupar regras por categoria
    regras_por_categoria = {}
    for regra in regras:
        categoria = regra['categoria']
        if categoria not in regras_por_categoria:
            regras_por_categoria[categoria] = []
        regras_por_categoria[categoria].append(regra)
    
    # Sidebar para seleção de regras
    st.sidebar.title("Configurações")
    
    # Multiselect para selecionar regras por categoria
    regras_selecionadas = []
    for categoria, lista_regras in regras_por_categoria.items():
        if lista_regras:  # Verificar se a lista não está vazia
            st.sidebar.subheader(categoria)
            nomes_regras = [r['nome'] for r in lista_regras]
            selecionadas = st.sidebar.multiselect(
                f"Selecione as regras de {categoria}:",
                nomes_regras,
                key=f"select_{categoria}"
            )
            
            # Adicionar regras selecionadas à lista
            for nome in selecionadas:
                for regra in lista_regras:
                    if regra['nome'] == nome:
                        regras_selecionadas.append(regra)
    
    # Número de amostras a serem geradas
    num_amostras = st.sidebar.number_input(
        "Número de amostras por regra:",
        min_value=1,
        max_value=100,
        value=50
    )
    
    # Configurações de busca no OpenSearch
    st.sidebar.subheader("Configurações de Busca")
    
    # Opção de fuzziness
    fuzziness_opcoes = ["0", "1", "2", "AUTO"]
    fuzziness = st.sidebar.selectbox(
        "Fuzziness (tolerância a erros):",
        fuzziness_opcoes,
        index=3,  # AUTO por padrão
        help="Controla a tolerância a erros na busca. '0' significa correspondência exata, '1' ou '2' permite 1 ou 2 mudanças de caracteres, 'AUTO' ajusta automaticamente com base no tamanho do termo."
    )
    
    # Opção de operator
    operator = st.sidebar.radio(
        "Operator:",
        ["or", "and"],
        index=0,  # "or" por padrão
        help="'or' encontra documentos que contenham qualquer termo da consulta. 'and' exige que todos os termos estejam presentes."
    )
    
    # Opção de minimum_should_match
    minimum_should_match_opcoes = ["1", "2", "50%", "75%", "100%"]
    minimum_should_match = st.sidebar.selectbox(
        "Minimum Should Match:",
        minimum_should_match_opcoes,
        index=0,  # "1" por padrão
        help="Define quantos termos da consulta devem corresponder. Pode ser um número absoluto ou uma porcentagem."
    )
    
    # Botão para executar a busca
    executar = st.sidebar.button("Executar Busca")
    
    # Verificar se há regras selecionadas
    if not regras_selecionadas:
        st.warning("Selecione pelo menos uma regra para processar.")
    
    # Exibir regras selecionadas
    if regras_selecionadas:
        st.subheader("Regras Selecionadas")
        for i, regra in enumerate(regras_selecionadas):
            st.write(f"**{i+1}. {regra['nome']}**: {regra.get('descricao', 'Sem descrição disponível')}")
    
    # Executar busca quando o botão for clicado
    if executar and regras_selecionadas:
        try:
            # Conectar ao OpenSearch
            client = get_opensearch_client()
            
            if not client:
                st.error("Não foi possível conectar ao OpenSearch. Verifique as configurações no arquivo .env")
                return
            
            # Processar cada regra selecionada
            with st.spinner("Processando regras selecionadas..."):
                for regra in regras_selecionadas:
                    st.subheader(f"Processando regra: {regra['nome']}")
                    st.write(f"**Categoria**: {regra['categoria']}")
                    st.write(f"**Descrição**: {regra['descricao']}")
                    
                    # Criar container para acompanhamento do progresso
                    progress_container = st.empty()
                    progress_bar = st.progress(0)
                    
                    # FASE 1: Selecionar nomes para o índice de treinamento com base na regra
                    progress_container.text("Fase 1: Buscando nomes relevantes do índice principal para a regra...")
                    
                    # Buscar nomes reais do índice lista-tratada com base na regra
                    progress_bar.progress(0.1)  # Atualizar barra de progresso
                    
                    # Buscar nomes relevantes para a regra do índice principal
                    progress_container.text(f"Buscando nomes relevantes para a regra '{regra['nome']}'...")
                    todos_resultados, query_info = buscar_nomes_do_indice(client, regra, quantidade=num_amostras)
                    
                    # Exibir a query utilizada para busca de amostras
                    with st.expander("Query utilizada para busca de amostras"):
                        st.code(query_info['query_formatada'], language="json")
                    
                    progress_bar.progress(0.5)  # Metade da barra de progresso
                    
                    # Exibir informações sobre os nomes encontrados
                    if todos_resultados:
                        # Verificar o tipo de regra para exibição personalizada
                        if 'remove_special_char' in regra.get('nome', '').lower() and len(todos_resultados) < num_amostras:
                            # Regra remove_special_char
                            st.warning(f"Encontrados apenas {len(todos_resultados)} nomes com caracteres especiais para a regra '{regra['nome']}'. O teste será realizado apenas com estes nomes.")
                            
                            # Mostrar informações sobre os caracteres especiais encontrados
                            with st.expander("Detalhes dos nomes com caracteres especiais"):
                                for i, doc in enumerate(todos_resultados[:10]):
                                    caracteres = doc.get('caracteres_especiais', '')
                                    st.write(f"{i+1}. {doc.get('nome', '')} (caracteres especiais: {caracteres})")
                                    
                        elif 'dbl2sgl' in regra.get('nome', '').lower() and len(todos_resultados) < num_amostras:
                            # Regra replace_dbl2sgl
                            st.warning(f"Encontrados apenas {len(todos_resultados)} nomes com letras duplicadas para a regra '{regra['nome']}'. O teste será realizado apenas com estes nomes.")
                            
                            # Mostrar informações sobre as letras duplicadas encontradas
                            with st.expander("Detalhes dos nomes com letras duplicadas"):
                                for i, doc in enumerate(todos_resultados[:10]):
                                    letras = doc.get('letras_duplicadas', '')
                                    st.write(f"{i+1}. {doc.get('nome', '')} (letras duplicadas: {letras})")
                        else:
                            st.info(f"Encontrados {len(todos_resultados)} nomes relevantes para a regra '{regra['nome']}'")
                            
                            # Mostrar alguns exemplos dos nomes encontrados
                            with st.expander("Exemplos de nomes encontrados"):
                                for i, doc in enumerate(todos_resultados[:5]):
                                    st.write(f"{i+1}. {doc.get('nome', '')}")
                    else:
                        # Mensagem genérica para todas as regras quando não encontra amostras
                        mensagem_erro = f"Não foram encontrados nomes adequados no índice para a regra '{regra['nome']}'. Não é possível realizar o teste."
                        
                        # Mensagens específicas para regras especiais
                        if 'remove_special_char' in regra.get('nome', '').lower():
                            st.error(f"Não foram encontrados nomes com caracteres especiais no índice para a regra '{regra['nome']}'. Não é possível realizar o teste.")
                        elif 'dbl2sgl' in regra.get('nome', '').lower():
                            st.error(f"Não foram encontrados nomes com letras duplicadas no índice para a regra '{regra['nome']}'. Não é possível realizar o teste.")
                        else:
                            st.error(mensagem_erro)
                            
                        # Pular para a próxima regra
                        continue
                    
                    # FASE 2: Indexar os nomes no índice de treinamento
                    progress_container.text("Fase 2: Indexando nomes no índice de treinamento...")
                    
                    # Indexar os resultados no índice de treinamento
                    sucesso, documentos_indexados = indexar_resultados(client, todos_resultados, regra)
                    
                    if not sucesso or not documentos_indexados:
                        st.error(f"Falha ao indexar nomes para a regra '{regra['nome']}'. Tente novamente.")
                        continue
                    
                    # FASE 3: Para cada nome, modificar e buscar no índice original
                    progress_container.text("Fase 3: Testando modificações e buscando resultados...")
                    
                    # Lista para armazenar os resultados dos testes
                    resultados_testes = []
                    
                    # Testar cada nome indexado
                    # Não limitamos mais a 10 para exibir todos os resultados
                    for i, doc in enumerate(documentos_indexados):
                        progress_container.text(f"Testando nome {i+1}/{len(documentos_indexados)}...")
                        progress_bar.progress(0.5 + (i+1)/(len(documentos_indexados)*2))  # Segunda metade da barra de progresso
                        
                        nome_original = doc['_source'].get('nome', '')
                        nome_modificado = doc['_source'].get('nome_modificado', '')
                        
                        # Construir query para buscar o nome modificado usando os parâmetros de busca selecionados
                        query_modificada = {
                            "size": 5,  # Aumentamos para pegar até 5 resultados
                            "query": {
                                "match": {
                                    "nome": {
                                        "query": nome_modificado,
                                        "fuzziness": fuzziness,
                                        "operator": operator
                                    }
                                }
                            }
                        }
                        
                        # Adicionar minimum_should_match se a consulta for do tipo bool
                        if "bool" in query_modificada["query"]:
                            # Converter minimum_should_match para inteiro ou manter como string conforme necessário
                            msm_value = minimum_should_match
                            if minimum_should_match.isdigit():
                                msm_value = int(minimum_should_match)
                            query_modificada["query"]["bool"]["minimum_should_match"] = msm_value
                        
                        # Executar busca com o nome modificado
                        resultado_busca, info_busca = executar_busca(client, query_modificada)
                        
                        # Armazenar a query utilizada para exibição posterior
                        query_utilizada = json.dumps(query_modificada, indent=2, ensure_ascii=False)
                        
                        # Encontrar o resultado com o score mais alto
                        melhor_resultado = None
                        score_mais_alto = 0
                        nome_melhor_resultado = ""
                        
                        if resultado_busca:
                            # Extrair o score de cada resultado
                            for hit in resultado_busca:
                                # Obter o score do hit
                                score = hit.get('_score', 0)
                                
                                # Extrair o nome do resultado (que agora está em _source)
                                if '_source' in hit and 'nome' in hit['_source']:
                                    nome = hit['_source']['nome']
                                else:
                                    nome = "Nome não encontrado"
                                
                                if score > score_mais_alto:
                                    score_mais_alto = score
                                    melhor_resultado = hit
                                    nome_melhor_resultado = nome
                            
                            # Se encontrou hits mas nenhum com score, use o primeiro hit
                            if not melhor_resultado and resultado_busca:
                                primeiro_hit = resultado_busca[0]
                                melhor_resultado = primeiro_hit
                                if '_source' in primeiro_hit and 'nome' in primeiro_hit['_source']:
                                    nome_melhor_resultado = primeiro_hit['_source']['nome']
                                else:
                                    nome_melhor_resultado = "Nome não encontrado"
                        
                        # Armazenar resultado do teste
                        resultados_testes.append({
                            'nome_original': nome_original,
                            'nome_modificado': nome_modificado,
                            'resultado_busca': melhor_resultado,  # Apenas o resultado com maior score
                            'info_busca': info_busca,
                            'regra_aplicada': regra['nome'],
                            'score_mais_alto': score_mais_alto,
                            'consulta_realizada': query_modificada,  # Armazenar a consulta realizada
                            'query_utilizada': query_utilizada,  # Armazenar a query formatada como string
                            'nome_melhor_resultado': nome_melhor_resultado,  # Nome do resultado com maior score
                            'fuzziness': fuzziness,  # Parâmetro de fuzziness usado
                            'operator': operator,  # Parâmetro de operator usado
                            'minimum_should_match': minimum_should_match  # Parâmetro de minimum_should_match usado
                        })
                    
                    # Limpar o container de progresso
                    progress_container.empty()
                    progress_bar.empty()
                    
                    # Sempre exibir resultados, mesmo que estejam vazios
                    st.success(f"Processados {len(resultados_testes)} nomes para a regra '{regra['nome']}'")
                    
                    # Criar DataFrame com os resultados para exibição e download
                    df_resultados = pd.DataFrame([
                        {
                            'Nome Original': teste['nome_original'],
                            'Nome Modificado': teste['nome_modificado'],
                            'Encontrou Resultado': 'Sim' if teste['resultado_busca'] else 'Não',
                            'Total Hits': teste['info_busca'].get('total_hits', 0),
                            'Score Mais Alto': f"{teste.get('score_mais_alto', 0):.4f}" if teste.get('score_mais_alto') is not None else 'N/A',  # Tratamento para None
                            'Tempo (ms)': teste['info_busca'].get('took_ms', 0),
                            'Regra Aplicada': teste['regra_aplicada'],
                            'Nome Encontrado': teste.get('nome_melhor_resultado', ''),  # Usando o nome do resultado com maior score
                            'Acerto': 'Sim' if teste['nome_original'] == teste.get('nome_melhor_resultado', '') else 'Não',  # Comparação entre nome original e encontrado
                            'Fuzziness': teste.get('fuzziness', 'AUTO'),  # Parâmetro de fuzziness usado
                            'Operator': teste.get('operator', 'or'),  # Parâmetro de operator usado
                            'Min Should Match': teste.get('minimum_should_match', '1')  # Parâmetro de minimum_should_match usado
                        } for teste in resultados_testes
                    ])
                    
                    # Exibir tabela completa com todos os resultados
                    st.subheader("Tabela de Resultados")
                    
                    # Aplicar estilo condicional para destacar em vermelho as linhas com Acerto = 'Não'
                    def highlight_rows(row):
                        if row['Acerto'] == 'Não':
                            return ['background-color: #ffcccc'] * len(row)
                        return [''] * len(row)
                    
                    # Aplicar o estilo e exibir o dataframe
                    st.dataframe(df_resultados.style.apply(highlight_rows, axis=1), use_container_width=True)
                    
                    # Calcular e exibir o percentual de acertos
                    total_amostras = len(df_resultados)
                    total_acertos = len(df_resultados[df_resultados['Acerto'] == 'Sim'])
                    percentual_acertos = (total_acertos / total_amostras * 100) if total_amostras > 0 else 0
                    
                    st.metric(
                        label="Percentual de Acertos", 
                        value=f"{percentual_acertos:.2f}%", 
                        delta=f"{total_acertos} de {total_amostras} amostras"
                    )
                    
                    # Gerar link para download
                    csv_download = gerar_csv_download(df_resultados.to_dict('records'), f"testes_{regra['nome']}")
                    st.markdown(csv_download, unsafe_allow_html=True)
                    
                    # Exibir alguns exemplos detalhados (limitado a 5 para não sobrecarregar a interface)
                    if resultados_testes:
                        st.subheader("Exemplos Detalhados")
                        exemplos_para_mostrar = resultados_testes[:5] if len(resultados_testes) > 5 else resultados_testes
                        
                        for i, teste in enumerate(exemplos_para_mostrar):
                            with st.expander(f"Exemplo {i+1}: {teste['nome_original']} → {teste['nome_modificado']}"):
                                col1, col2 = st.columns(2)
                                
                                with col1:
                                    st.markdown("**Nome Original**")
                                    st.code(teste['nome_original'])
                                    
                                    st.markdown("**Nome Modificado**")
                                    st.code(teste['nome_modificado'])
                                    
                                    st.markdown("**Parâmetros de Busca Utilizados**")
                                    st.write(f"Fuzziness: `{teste.get('fuzziness', 'AUTO')}`")
                                    st.write(f"Operator: `{teste.get('operator', 'or')}`")
                                    st.write(f"Minimum Should Match: `{teste.get('minimum_should_match', '1')}`")
                                    
                                    st.markdown("**Consulta DSL Realizada**")
                                    st.code(teste.get('query_utilizada', json.dumps(teste['consulta_realizada'], indent=2, ensure_ascii=False)), language="json")
                                    
                                    st.markdown("**Informações da Busca**")
                                    st.write(f"Total de resultados: {teste['info_busca'].get('total_hits', 0)}")
                                    
                                    # Tratamento para evitar erro de formatação com None
                                    max_score = teste['info_busca'].get('max_score')
                                    if max_score is not None:
                                        st.write(f"Pontuação máxima: {max_score:.4f}")
                                    else:
                                        st.write("Pontuação máxima: N/A")
                                        
                                    st.write(f"Tempo de busca: {teste['info_busca'].get('took_ms', 0)} ms")
                                
                                with col2:
                                    st.markdown("**Resultado com Maior Score**")
                                    if teste['resultado_busca']:
                                        # Exibir informações sobre o resultado com maior score
                                        st.markdown(f"**Nome encontrado:** {teste.get('nome_melhor_resultado', '')}")
                                        
                                        # Tratamento para evitar erro de formatação com None
                                        score_mais_alto = teste.get('score_mais_alto')
                                        if score_mais_alto is not None:
                                            st.markdown(f"**Score:** {score_mais_alto:.4f}")
                                        else:
                                            st.markdown("**Score:** N/A")
                                        
                                        # Exibir o documento fonte
                                        if '_source' in teste['resultado_busca']:
                                            st.markdown("**Dados do documento:**")
                                            st.json(teste['resultado_busca']['_source'])
                                        
                                        # Exibir o resultado completo em formato JSON
                                        st.markdown("**Detalhes completos do hit:**")
                                        st.json(teste['resultado_busca'])
                                    else:
                                        st.warning("Nenhum resultado encontrado para o nome modificado")
                    else:
                        st.info("Não há exemplos detalhados para exibir, mas a tabela acima mostra o resumo dos testes.")
                    
                    # Adicionar separador entre regras
                    st.markdown("---")
        except Exception as e:
            st.error(f"Erro durante a execução: {str(e)}")
            logger.error(f"Erro durante a execução: {str(e)}")

if __name__ == "__main__":
    main()